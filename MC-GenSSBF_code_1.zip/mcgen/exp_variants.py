"""Compare codebook variants feeding MC-CFM: SU, IA (shape logdet), CIA (conditional), and joint refinement."""
import copy, sys, time
import torch
from exp_insite import load_site, joint_refine
from mcgenssbf.core import SysParams
from mcgenssbf.schemes import codebook_set, codebook_metrics, make_gen, fit_gen, GenScheme, link_eval, network_eval, summarize
torch.set_num_threads(2)
site, seed = sys.argv[1], int(sys.argv[2])
sp = SysParams(n_ant=32, K=8, M=8)
sd = load_site(site, 32)
out = {}
t0 = time.time()
def run(name, cbs, joint=False):
    torch.manual_seed(seed)
    m = make_gen("cfm", sp, "full")
    fit_gen(m, [sd], [cbs], sp, "full", epochs=40, seed=seed)
    if joint:
        cbs = joint_refine(sd, cbs, m, sp, "full", rounds=3, cb_steps=60, gen_epochs=8, seed=seed)
    sc = GenScheme(name, cbs, m, "full")
    r = link_eval(sc, sd, sp, 8)
    net = network_eval(sd, sp, [sc], n_drops=150, U=4, M=8, seed=seed, sched_modes=("coord",))
    out[name] = {**codebook_metrics(sd, cbs, sp), "gap": float(r["gap"].mean()),
                 "leak_strong": float(r["leak_err_db"][r["leak_strong"]].abs().mean()), **summarize(net[name]["coord"])}
    print(site, name, {k: round(v, 3) for k, v in out[name].items()}, f"{time.time()-t0:.0f}s", flush=True)
su = codebook_set(sd, sp, "su", seed=seed)
run("SU", su)
run("SU+joint", su, joint=True)
for li in (0.1, 0.3):
    run(f"CIA{li}", codebook_set(sd, sp, "cia", seed=seed, lam_int=li))
run("IA0.25", codebook_set(sd, sp, "ia", seed=seed, lam_int=0.25))
torch.save(out, f"results/variants_{site}_s{seed}.pt")
