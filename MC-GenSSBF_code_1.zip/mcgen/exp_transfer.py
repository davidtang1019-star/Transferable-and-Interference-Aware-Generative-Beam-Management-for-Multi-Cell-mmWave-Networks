"""Cross-site transfer: multi-site pre-training + few-shot target adaptation.

Usage: python exp_transfer.py SEED [--quick]
"""
import copy
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch

from mcgenssbf.sites import default_sites, make_site, build_site_dataset
from mcgenssbf.core import SysParams, train_codebook, dft_codebook, MCCFM
from mcgenssbf.pipeline import SiteData, B
from mcgenssbf.schemes import GenScheme, fit_gen, link_eval, codebook_metrics, network_eval, summarize

torch.set_num_threads(int(__import__("os").environ.get("NTHREADS", "2")))
OUT = Path("results")
OUT.mkdir(exist_ok=True)
TARGETS = ["LOS-5", "BLK-5"]


def load_all(n_ant, spacing=0.6):
    sds = {}
    for i, c in enumerate(default_sites()):
        sd = SiteData(build_site_dataset(make_site(c, ue_spacing=spacing), n_ant), site_id=i)
        sds[c.name] = sd
    return sds


def pooled_codebook(sources, sp, seed, epochs, mode="ia"):
    hs = torch.cat([sd.h_serv(b) for sd in sources for b in range(B)])
    hi = torch.cat([sd.h_int(b) for sd in sources for b in range(B)])
    w, _ = train_codebook(hs, hi, sp, mode=mode, epochs=epochs, seed=seed)
    return w


def reptile(model, sources, cbs, sp, outer=60, inner=15, eps=0.3, n_users=150, seed=0):
    """First-order meta-learning (Reptile) over source sites with few-shot-sized inner tasks."""
    rng = np.random.default_rng(seed)
    for it in range(outer):
        k = int(rng.integers(len(sources)))
        fast = copy.deepcopy(model)
        fit_gen(fast, [sources[k]], [cbs], sp, "full", epochs=max(1, inner // 4), lr=5e-4, use_meta=True,
                subset=n_users, seed=seed * 1000 + it)
        with torch.no_grad():
            for p, q in zip(model.parameters(), fast.parameters()):
                p.add_(eps * (1 - it / outer) * (q - p))
    return model


def adapt(base, sd, cb, sp, n_shot, method, steps=300, seed=0):
    m = copy.deepcopy(base)
    if method == "zero":
        return m
    # approximate number of links per UE ~ 2 -> epochs to reach `steps` updates of batch 64
    n_links = max(2 * n_shot, 2)
    bs = 64
    epochs = max(1, int(math.ceil(steps * bs / n_links)))
    if method == "lora":
        for p in m.parameters():
            p.requires_grad_(False)
        m.set_lora(True)
        params = []
        for mod in m.lora_modules():
            mod.A.requires_grad_(True)
            mod.B.requires_grad_(True)
            params += [mod.A, mod.B]
        m.enc.site_offset.requires_grad_(True)
        params.append(m.enc.site_offset)
        for p in m.gain_head.parameters():
            p.requires_grad_(True)
            params.append(p)
        fit_gen(m, [sd], [cb], sp, "full", epochs=epochs, lr=2e-3, bs=bs, use_meta=True, params=params,
                subset=n_shot, seed=seed)
    elif method == "full":
        fit_gen(m, [sd], [cb], sp, "full", epochs=epochs, lr=3e-4, bs=bs, use_meta=True, subset=n_shot, seed=seed)
    elif method == "scratch":
        m = MCCFM(sp.n_ant, sp.K, 2 * sp.K, 0, 0)
        fit_gen(m, [sd], [cb], sp, "full", epochs=2 * epochs, lr=1e-3, bs=bs, use_meta=False, subset=n_shot,
                seed=seed)
    return m


def main():
    seed = int(sys.argv[1])
    quick = "--quick" in sys.argv
    torch.manual_seed(seed)
    sp = SysParams(n_ant=32, K=8, M=8, pt_dbm=30.0)
    t0 = time.time()
    sds = load_all(sp.n_ant)
    sources = [sd for n, sd in sds.items() if n not in TARGETS]
    print("loaded", {n: int(sd.H.shape[1]) for n, sd in sds.items()}, f"{time.time()-t0:.0f}s", flush=True)
    R = {"seed": seed}
    cbe = 8 if quick else 40
    cb_ia = pooled_codebook(sources, sp, seed, cbe, "su")  # pooled SIM codebook shared by all cells
    cb_dft = dft_codebook(sp.n_ant, sp.K)
    cbs_ia, cbs_dft = [cb_ia] * B, [cb_dft] * B
    pe = 2 if quick else 10
    pre = {}
    for cbk, cbs in (("ia", cbs_ia), ("dft", cbs_dft)):
        torch.manual_seed(seed)
        m = MCCFM(sp.n_ant, sp.K, 2 * sp.K, meta_dim=8, n_sites=len(sds))
        h, _ = fit_gen(m, sources, [cbs] * len(sources), sp, "full", epochs=pe, use_meta=True, seed=seed,
                       max_links=60000, verbose=True)
        pre[cbk] = m
        print(f"pretrained ({cbk}) {time.time()-t0:.0f}s", flush=True)
    pre["ia_meta"] = reptile(copy.deepcopy(pre["ia"]), sources, cbs_ia, sp, outer=6 if quick else 60, seed=seed)
    print(f"reptile {time.time()-t0:.0f}s", flush=True)
    # ablation: pretrained without site metadata/embedding
    torch.manual_seed(seed)
    m_nometa = MCCFM(sp.n_ant, sp.K, 2 * sp.K, meta_dim=0)
    fit_gen(m_nometa, sources, [cbs_ia] * len(sources), sp, "full", epochs=pe, use_meta=False, seed=seed,
            max_links=60000)
    pre["ia_nometa"] = m_nometa
    print(f"pretrained (no meta) {time.time()-t0:.0f}s", flush=True)

    shots = [25, 50, 100, 250, 500] if not quick else [50]
    R["targets"] = {}
    for tn in TARGETS:
        sd = sds[tn]
        T = {}
        # site-specific reference: in-site IA codebooks + model trained on the full target training set
        cb_site = [train_codebook(sd.h_serv(b), sd.h_int(b), sp, "su", epochs=cbe, seed=seed + b)[0] for b in range(B)]
        torch.manual_seed(seed)
        m_site = MCCFM(sp.n_ant, sp.K, 2 * sp.K)
        fit_gen(m_site, [sd], [cb_site], sp, "full", epochs=4 if quick else 40, seed=seed)
        T["site_specific"] = float(link_eval(GenScheme("ss", cb_site, m_site, "full"), sd, sp, sp.M)["gap"].mean())
        T["n_train_ue"] = int(len(sd.idx["train"]))
        T["cb_metrics"] = {"pooled_ia": codebook_metrics(sd, cbs_ia, sp), "site_ia": codebook_metrics(sd, cb_site, sp),
                           "dft": codebook_metrics(sd, cbs_dft, sp)}

        def ev(model, cbs, use_meta=True):
            return float(link_eval(GenScheme("x", cbs, model, "full", use_meta=use_meta), sd, sp, sp.M)["gap"].mean())

        T["zero"] = {"proposed": ev(pre["ia_meta"], cbs_ia), "joint_pre": ev(pre["ia"], cbs_ia),
                     "dft": ev(pre["dft"], cbs_dft), "nometa": ev(pre["ia_nometa"], cbs_ia, use_meta=False)}
        T["few"] = {}
        for n in shots:
            row = {}
            row["scratch"] = ev(adapt(None, sd, cbs_ia, sp, n, "scratch", seed=seed), cbs_ia, use_meta=False)
            row["full_ft"] = ev(adapt(pre["ia"], sd, cbs_ia, sp, n, "full", seed=seed), cbs_ia)
            row["lora_joint_pre"] = ev(adapt(pre["ia"], sd, cbs_ia, sp, n, "lora", seed=seed), cbs_ia)
            row["lora_meta"] = ev(adapt(pre["ia_meta"], sd, cbs_ia, sp, n, "lora", seed=seed), cbs_ia)
            row["lora_meta_dft"] = ev(adapt(pre["dft"], sd, cbs_dft, sp, n, "lora", seed=seed), cbs_dft)
            # joint adaptation: refine the pooled codebook on the n target channels, then LoRA
            users = sd.idx["train"][torch.randperm(len(sd.idx["train"]), generator=torch.Generator().manual_seed(seed))[:n]]
            cbs_j = []
            for b in range(B):
                hs = sd.H[b, users[sd.serv[users] == b]]
                hi = sd.H[b, users[sd.serv[users] != b]]
                if hs.shape[0] < sp.K + 2:
                    cbs_j.append(cb_ia)
                    continue
                w, _ = train_codebook(hs, hi, sp, "su", epochs=max(5, 2000 // max(hs.shape[0], 1)), lr=5e-3,
                                      seed=seed, init=cb_ia, bs=256)
                cbs_j.append(w)
            row["lora_meta_jointcb"] = ev(adapt(pre["ia_meta"], sd, cbs_j, sp, n, "lora", seed=seed), cbs_j)
            T["few"][n] = row
            print(tn, n, {k: round(v, 2) for k, v in row.items()}, f"{time.time()-t0:.0f}s", flush=True)
        # network-level comparison at N_shot = 100 (or the quick value)
        n = 100 if 100 in shots else shots[0]
        mods = {"Zero-shot": GenScheme("Zero-shot", cbs_ia, pre["ia_meta"], "full", use_meta=True),
                "Scratch": GenScheme("Scratch", cbs_ia, adapt(None, sd, cbs_ia, sp, n, "scratch", seed=seed), "full"),
                "LoRA+meta": GenScheme("LoRA+meta", cbs_ia, adapt(pre["ia_meta"], sd, cbs_ia, sp, n, "lora", seed=seed),
                                       "full", use_meta=True),
                "Site-specific": GenScheme("Site-specific", cb_site, m_site, "full")}
        res = network_eval(sd, sp, list(mods.values()), n_drops=40 if quick else 150, U=4, M=sp.M, seed=seed,
                           sched_modes=("coord",))
        T["net"] = {k: summarize(v["coord"]) for k, v in res.items()}
        print(tn, "net", {k: round(v["wsr"], 3) for k, v in T["net"].items()}, flush=True)
        R["targets"][tn] = T
    R["time_s"] = time.time() - t0
    torch.save(R, OUT / f"transfer_s{seed}{'_quick' if quick else ''}.pt")
    print("done", f"{time.time()-t0:.0f}s")


if __name__ == "__main__":
    main()
