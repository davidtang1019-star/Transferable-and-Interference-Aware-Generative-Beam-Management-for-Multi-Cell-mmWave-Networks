#!/bin/bash
# usage: runq.sh JOBFILE  (each line a command); runs 2 workers
JOBS=$1
run_worker() {
  while true; do
    exec 9>/home/claude/mcgen/results/.lock
    flock 9
    line=$(head -n1 "$JOBS"); [ -n "$line" ] && sed -i '1d' "$JOBS"
    flock -u 9
    [ -z "$line" ] && break
    echo "[$(date +%H:%M:%S)] start: $line" >> results/queue.log
    NTHREADS=1 bash -c "$line" >> results/queue_$1.log 2>&1
    echo "[$(date +%H:%M:%S)] done: $line" >> results/queue.log
  done
}
run_worker A & run_worker B & wait
