"""Aggregate result files into figures (PDF) and LaTeX tables with mean +- 95% CI over seeds."""
import glob
import json
import math
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy import stats

FIG = Path("/home/claude/paper/figs")
TAB = Path("/home/claude/paper")
FIG.mkdir(exist_ok=True, parents=True)
plt.rcParams.update({"font.size": 9, "axes.grid": True, "grid.alpha": 0.3, "legend.fontsize": 7.5,
                     "figure.dpi": 130, "lines.linewidth": 1.4, "lines.markersize": 4.5})
PAL = {"DFT+MLP": "#7f7f7f", "DFT+CFM": "#bcbd22", "SU-SIM+CFM": "#1f77b4", "SU-SIM+MC-CFM": "#17becf",
       "IA-SIM+MC-CFM": "#9467bd", "CIA-SIM+CFM": "#8c564b", "CIA-SIM+MC-CFM": "#ff7f0e",
       "CIA-SIM+MC-CFM (stats)": "#e377c2", "Proposed": "#d62728", "beamsearch": "#2ca02c", "srs": "#000000",
       "genie": "#555555", "Beam search": "#2ca02c", "SRS-LMMSE": "#000000"}
LABEL = {"beamsearch": "Hier. search", "srs": "SRS-LMMSE", "genie": "Genie (MRT + true CSI)",
         "SU-SIM+CFM": "SU-SIM+CFM (GenSSBF)", "Proposed": "Proposed (CIA+MC-CFM, joint)", "Beam search": "Hier. search"}
SITES = ["LOS-1", "LOS-3", "BLK-1", "BLK-3"]


def ci(x):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if len(x) < 2:
        return float(np.mean(x)) if len(x) else float("nan"), 0.0
    return float(x.mean()), float(stats.t.ppf(0.975, len(x) - 1) * x.std(ddof=1) / math.sqrt(len(x)))


def load(pattern):
    out = []
    for f in sorted(glob.glob(pattern)):
        if "quick" in f:
            continue
        out.append(torch.load(f, weights_only=False))
    return out


def fmt(m, h, d=2):
    return f"{m:.{d}f}$\\pm${h:.{d}f}"


# ============================================================================ in-site
def insite():
    runs = defaultdict(list)
    for R in load("results/insite_*_s*.pt"):
        runs[R["site"]].append(R)
    sites = [s for s in SITES if s in runs]
    if not sites:
        return {}
    print({s: len(runs[s]) for s in sites})
    summary = {}
    # ---------------- codebook table
    cbk = ["dft", "su", "ia", "cia", "joint"]
    cbn = {"dft": "DFT", "su": "SIM~\\cite{zhao2026genssbf}", "ia": "IA-SIM, Eq.~(\\ref{eq:ia})",
           "cia": "CIA-SIM, Eq.~(\\ref{eq:cia})", "joint": "CIA-SIM + joint refinement"}
    lines = []
    for k in cbk:
        row = [cbn[k]]
        for fam in ("LOS", "BLK"):
            ss = [s for s in sites if s.startswith(fam)]
            for met in ("logdet_serv", "logdet_int", "cover"):
                vals = [R["codebook"][k][met] for s in ss for R in runs[s] if k in R["codebook"]]
                m, h = ci(vals)
                row.append(f"{m:.2f}" if met != "cover" else f"{100*m:.0f}")
        lines.append(" & ".join(row) + " \\\\")
    (TAB / "tab_codebook_rows.tex").write_text("\n".join(lines) + "\n")

    # ---------------- link-level table (gap, within-1dB, leakage MAE strong) per family
    names = ["DFT+MLP", "DFT+CFM", "SU-SIM+CFM", "SU-SIM+MC-CFM", "IA-SIM+MC-CFM", "CIA-SIM+CFM", "CIA-SIM+MC-CFM",
             "CIA-SIM+MC-CFM (stats)", "Proposed"]
    lines = []
    link_sum = {}
    for n in names:
        row = [LABEL.get(n, n).replace("(GenSSBF)", "\\cite{zhao2026genssbf}")]
        for fam in ("LOS", "BLK"):
            ss = [s for s in sites if s.startswith(fam)]
            g = [float(np.mean(R["link"][n]["gap"])) for s in ss for R in runs[s]]
            w1 = [float(np.mean(R["link"][n]["gap"] >= -1)) * 100 for s in ss for R in runs[s]]
            le = [float(np.mean(np.abs(R["link"][n]["leak_err_db"][R["link"][n]["leak_strong"]]))) for s in ss for R in runs[s]]
            m1, h1 = ci(g)
            m2, h2 = ci(w1)
            m3, h3 = ci(le)
            link_sum[(n, fam)] = (m1, h1, m2, m3, h3)
            row += [fmt(m1, h1), f"{m2:.0f}", fmt(m3, h3, 1)]
        lines.append(" & ".join(row) + " \\\\")
    (TAB / "tab_link_rows.tex").write_text("\n".join(lines) + "\n")
    summary["link"] = {f"{a}|{b}": v for (a, b), v in link_sum.items()}

    # ---------------- CDF of gap (one LOS and one BLK site, seed 0)
    fig, axs = plt.subplots(1, 2, figsize=(8.6, 3.3))
    for ax, s in zip(axs, [x for x in ("LOS-1", "BLK-1") if x in runs]):
        R = runs[s][0]
        for n in ("DFT+MLP", "DFT+CFM", "SU-SIM+CFM", "CIA-SIM+MC-CFM", "Proposed"):
            g = np.sort(R["link"][n]["gap"])
            ax.plot(g, np.arange(1, len(g) + 1) / len(g), label=LABEL.get(n, n), color=PAL[n])
        ax.set_xlim(-12, 0.2)
        ax.set_xlabel("Gap to MRT (dB)")
        ax.set_ylabel("Empirical CDF")
        ax.set_title(f"{s} (seed {R['seed']}, $K{{=}}M{{=}}8$)")
    axs[0].legend(loc="upper left")
    plt.tight_layout()
    plt.savefig(FIG / "fig_gap_cdf.pdf", bbox_inches="tight")
    plt.close()

    # ---------------- gap vs Pt (family means)
    fig, axs = plt.subplots(1, 2, figsize=(8.6, 3.3))
    for ax, fam in zip(axs, ("LOS", "BLK")):
        ss = [s for s in sites if s.startswith(fam)]
        pts = sorted(runs[ss[0]][0]["gap_vs_pt"].keys())
        for n in ("DFT+MLP", "DFT+CFM", "SU-SIM+CFM", "CIA-SIM+MC-CFM", "Proposed", "Beam search", "SRS-LMMSE"):
            ms, hs = zip(*[ci([R["gap_vs_pt"][p][n] for s in ss for R in runs[s]]) for p in pts])
            ax.errorbar(pts, ms, yerr=hs, marker="o", capsize=2, label=LABEL.get(n, n), color=PAL[n],
                        ls="--" if n in ("Beam search", "SRS-LMMSE") else "-")
        ax.set_xlabel("Transmit power $P_t$ (dBm)")
        ax.set_ylabel("Mean gap to MRT (dB)")
        ax.set_title(f"{fam} sites ({', '.join(ss)})")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=4, fontsize=7, bbox_to_anchor=(0.5, -0.02))
    plt.tight_layout(rect=(0, 0.12, 1, 1))
    plt.savefig(FIG / "fig_gap_pt.pdf", bbox_inches="tight")
    plt.close()

    # ---------------- network table at 30 dBm
    net_names = ["DFT+MLP", "DFT+CFM", "SU-SIM+CFM", "SU-SIM+MC-CFM", "IA-SIM+MC-CFM", "CIA-SIM+CFM", "CIA-SIM+MC-CFM",
                 "CIA-SIM+MC-CFM (stats)", "Proposed", "beamsearch", "srs", "genie"]
    lines = []
    net_sum = {}
    for n in net_names:
        for mode in ("unc", "coord"):
            row = [LABEL.get(n, n).replace("(GenSSBF)", "\\cite{zhao2026genssbf}"), "C" if mode == "coord" else "U"]
            for fam in ("LOS", "BLK"):
                ss = [s for s in sites if s.startswith(fam)]
                for met, d in (("wsr", 2), ("p5_sinr", 1), ("edge_rate", 2)):
                    m, h = ci([R["net"][30.0][n][mode][met] for s in ss for R in runs[s]])
                    net_sum[(n, mode, fam, met)] = (m, h)
                    row.append(fmt(m, h, d))
            lines.append(" & ".join(row) + " \\\\")
    for mode, lab in (("genie", "C$^\\star$"), ("coord_bestidx", "C$_{\\mathrm{idx}}$")):
        row = ["Proposed", lab]
        for fam in ("LOS", "BLK"):
            ss = [s for s in sites if s.startswith(fam)]
            for met, d in (("wsr", 2), ("p5_sinr", 1), ("edge_rate", 2)):
                m, h = ci([R["net"][30.0]["Proposed"][mode][met] for s in ss for R in runs[s]])
                net_sum[("Proposed", mode, fam, met)] = (m, h)
                row.append(fmt(m, h, d))
        lines.append(" & ".join(row) + " \\\\")
    (TAB / "tab_net_rows.tex").write_text("\n".join(lines) + "\n")
    summary["net"] = {"|".join(map(str, k)): v for k, v in net_sum.items()}

    # paired differences Proposed vs SU-SIM+CFM (coord) per run, WSR at 30 dBm
    pd = {}
    for fam in ("LOS", "BLK"):
        ss = [s for s in sites if s.startswith(fam)]
        for other in ("SU-SIM+CFM", "DFT+CFM", "CIA-SIM+MC-CFM", "beamsearch"):
            d = [R["net"][30.0]["Proposed"]["coord"]["wsr"] - R["net"][30.0][other]["coord"]["wsr"] for s in ss for R in runs[s]]
            pd[f"{fam}|{other}"] = ci(d) + (len(d), float(stats.ttest_1samp(d, 0).pvalue) if len(d) > 1 else float("nan"))
        d = [R["net"][30.0]["Proposed"]["coord"]["wsr"] / R["net"][30.0]["Proposed"]["unc"]["wsr"] - 1 for s in ss for R in runs[s]]
        pd[f"{fam}|coord_gain"] = ci(d)
        d = [R["net"][30.0]["Proposed"]["coord"]["wsr"] / R["net"][30.0]["Proposed"]["genie"]["wsr"] for s in ss for R in runs[s]]
        pd[f"{fam}|frac_genie"] = ci(d)
    summary["paired"] = pd

    # ---------------- network WSR vs Pt
    fig, axs = plt.subplots(1, 2, figsize=(8.6, 3.3))
    for ax, fam in zip(axs, ("LOS", "BLK")):
        ss = [s for s in sites if s.startswith(fam)]
        pts = sorted(runs[ss[0]][0]["net"].keys())
        for n, mode in (("SU-SIM+CFM", "unc"), ("SU-SIM+CFM", "coord"), ("DFT+CFM", "coord"), ("Proposed", "unc"),
                        ("Proposed", "coord"), ("beamsearch", "coord"), ("srs", "coord")):
            ms, hs = zip(*[ci([R["net"][p][n][mode]["wsr"] for s in ss for R in runs[s]]) for p in pts])
            ax.errorbar(pts, ms, yerr=hs, marker="o" if mode == "coord" else "s", capsize=2, color=PAL[n],
                        ls="-" if mode == "coord" else ":", label=f"{LABEL.get(n, n)}, {'coord.' if mode == 'coord' else 'uncoord.'}")
        ax.set_xlabel("Transmit power $P_t$ (dBm)")
        ax.set_ylabel("Network WSR (bit/s/Hz)")
        ax.set_title(f"{fam} sites")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=4, fontsize=7, bbox_to_anchor=(0.5, -0.02))
    plt.tight_layout(rect=(0, 0.12, 1, 1))
    plt.savefig(FIG / "fig_net_pt.pdf", bbox_inches="tight")
    plt.close()

    # ---------------- SINR CDF for scheduled UEs (LOS-1 / BLK-1 seed0 @30 dBm)
    fig, axs = plt.subplots(1, 2, figsize=(8.6, 3.3))
    for ax, s in zip(axs, [x for x in ("LOS-1", "BLK-1") if x in runs]):
        raw = runs[s][0]["net_raw30"]
        for n, mode in (("SU-SIM+CFM", "unc"), ("SU-SIM+CFM", "coord"), ("Proposed", "unc"), ("Proposed", "coord"),
                        ("srs", "coord")):
            v = np.sort(raw[n][mode]["sinr_db"])
            ax.plot(v, np.arange(1, len(v) + 1) / len(v), color=PAL[n], ls="-" if mode == "coord" else ":",
                    label=f"{LABEL.get(n, n)}, {'coord.' if mode == 'coord' else 'uncoord.'}")
        ax.set_xlabel("SINR of scheduled UEs (dB)")
        ax.set_ylabel("Empirical CDF")
        ax.set_title(f"{s}, $P_t$ = 30 dBm")
        ax.set_xlim(-10, 60)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=3, fontsize=7, bbox_to_anchor=(0.5, -0.02))
    plt.tight_layout(rect=(0, 0.12, 1, 1))
    plt.savefig(FIG / "fig_sinr_cdf.pdf", bbox_inches="tight")
    plt.close()

    # ---------------- overhead-performance (M sweep): gap and WSR vs channel uses
    fig, axs = plt.subplots(1, 2, figsize=(8.6, 3.3))
    K = 8
    for fam, mk in (("LOS", "o"), ("BLK", "s")):
        ss = [s for s in sites if s.startswith(fam)]
        Ms = sorted(runs[ss[0]][0]["gap_vs_M"]["Proposed"].keys())
        for n, ov in (("SU-SIM+CFM", lambda M: 2 * K + M + 1), ("Proposed", lambda M: 2 * K + 2 * K + M + 1)):
            ms, hs = zip(*[ci([R["gap_vs_M"][n][M] for s in ss for R in runs[s]]) for M in Ms])
            axs[0].errorbar([ov(M) for M in Ms], ms, yerr=hs, marker=mk, capsize=2, color=PAL[n],
                            ls="-" if fam == "LOS" else "--", label=f"{LABEL.get(n, n)}, {fam}")
            ms, hs = zip(*[ci([R["net_vs_M"][M][n]["wsr"] for s in ss for R in runs[s]]) for M in Ms])
            axs[1].errorbar([ov(M) for M in Ms], ms, yerr=hs, marker=mk, capsize=2, color=PAL[n],
                            ls="-" if fam == "LOS" else "--", label=f"{LABEL.get(n, n)}, {fam}")
        for i, M in enumerate(Ms):
            axs[0].annotate(f"M={M}", (2 * K + 2 * K + M + 1, ci([R["gap_vs_M"]["Proposed"][M] for s in ss for R in runs[s]])[0]),
                            fontsize=6, xytext=(2, -8), textcoords="offset points") if fam == "LOS" else None
    axs[0].set_xlabel("Online overhead (channel uses)")
    axs[0].set_ylabel("Mean gap to MRT (dB)")
    axs[1].set_xlabel("Online overhead (channel uses)")
    axs[1].set_ylabel("Network WSR (bit/s/Hz), coord.")
    axs[0].legend(fontsize=6.5)
    plt.tight_layout()
    plt.savefig(FIG / "fig_overhead_M.pdf", bbox_inches="tight")
    plt.close()

    # greedy optimality + time
    gr = [np.mean(R["greedy_ratio"]) for s in sites for R in runs[s]]
    allr = np.concatenate([R["greedy_ratio"] for s in sites for R in runs[s]])
    summary["greedy"] = {"mean": float(np.mean(allr)), "min": float(np.min(allr)), "p10": float(np.percentile(allr, 10)),
                         "n": int(len(allr))}
    summary["n_runs"] = {s: len(runs[s]) for s in sites}
    summary["n_ue"] = {s: runs[s][0]["n_ue"] for s in sites}
    summary["time_s"] = float(np.mean([R["time_s"] for s in sites for R in runs[s]]))

    # beam patterns (LOS-1 / BLK-1 seed 0, cell 0)
    import math as m_
    fig, axs = plt.subplots(2, 3, figsize=(9, 4.6), subplot_kw={"projection": "polar"})
    for r_, s in enumerate([x for x in ("LOS-1", "BLK-1") if x in runs]):
        R = runs[s][0]
        for c_, k in enumerate(("su", "cia", "dft")):
            W = R["codebooks"][k][0]
            th = np.linspace(-np.pi / 2, np.pi / 2, 721)
            A = np.exp(1j * np.pi * np.outer(np.sin(th), np.arange(W.shape[0])))
            P = np.abs(A.conj() @ W) ** 2
            ax = axs[r_, c_]
            Pn = P / P.max()
            for j in range(W.shape[1]):
                ax.plot(th, np.maximum(10 * np.log10(Pn[:, j] + 1e-12), -20) + 20, lw=0.7)
            ax.set_theta_direction(-1)
            ax.set_thetamin(-90)
            ax.set_thetamax(90)
            ax.set_theta_zero_location("N")
            ax.set_rticks([])
            ax.set_title(f"{s}: {dict(su='SIM', cia='CIA-SIM', dft='DFT')[k]}", fontsize=8)
    plt.tight_layout()
    plt.savefig(FIG / "fig_beams.pdf", bbox_inches="tight")
    plt.close()
    return summary


# ============================================================================ sweep (IA / CIA)
def sweeps():
    out = {}
    fig, axs = plt.subplots(1, 2, figsize=(8.6, 3.1))
    for s, c in (("LOS-1", "#1f77b4"), ("BLK-1", "#d62728")):
        f = f"results/sweep_ia_{s}_K8_s0.pt"
        if not Path(f).exists():
            continue
        R = torch.load(f, weights_only=False)
        lis = sorted({k[0] for k in R})
        ld = [R[(l, 0.05)]["logdet_int"] for l in lis]
        lk = [R[(l, 0.05)]["leak_mae_strong"] for l in lis]
        gp = [R[(l, 0.05)]["gap"] for l in lis]
        axs[0].plot(lis, ld, "o-", color=c, label=s)
        axs[1].plot(lis, lk, "o-", color=c, label=f"{s}: leakage MAE (dB)")
        axs[1].plot(lis, [-g for g in gp], "s--", color=c, label=f"{s}: |gap to MRT| (dB)")
        out[s] = {"lam": lis, "logdet_int": ld, "leak": lk, "gap": gp}
    axs[0].set_xlabel("$\\lambda_3$ (IA-SIM)")
    axs[0].set_ylabel("$\\log\\det\\hat{R}$ over victims $\\mathcal{V}_b$")
    axs[0].legend()
    axs[1].set_xlabel("$\\lambda_3$ (IA-SIM)")
    axs[1].set_ylabel("Error (dB)")
    axs[1].legend(fontsize=6.5)
    plt.tight_layout()
    plt.savefig(FIG / "fig_ia_sweep.pdf", bbox_inches="tight")
    plt.close()
    return out


# ============================================================================ transfer
def transfer():
    runs = load("results/transfer_s*.pt")
    if not runs:
        return {}
    out = {"n_seeds": len(runs)}
    fig, axs = plt.subplots(1, 2, figsize=(8.6, 3.3))
    meth = [("scratch", "Scratch (target only)", "#7f7f7f", "s--"), ("full_ft", "Pre-trained + full fine-tune", "#1f77b4", "o-"),
            ("lora_joint_pre", "Joint pre-train + LoRA", "#17becf", "^-"), ("lora_meta", "Reptile + LoRA", "#d62728", "o-"),
            ("lora_meta_jointcb", "Reptile + LoRA + codebook adapt.", "#ff7f0e", "d-"),
            ("lora_meta_dft", "Reptile + LoRA, DFT codebook", "#bcbd22", "v:")]
    for ax, tn in zip(axs, ("LOS-5", "BLK-5")):
        shots = sorted(runs[0]["targets"][tn]["few"].keys())
        for k, lab, c, st in meth:
            ms, hs = zip(*[ci([R["targets"][tn]["few"][n][k] for R in runs]) for n in shots])
            ax.errorbar(shots, ms, yerr=hs, fmt=st, color=c, capsize=2, label=lab)
            out[f"{tn}|{k}"] = list(zip(shots, ms, hs))
        z = ci([R["targets"][tn]["zero"]["proposed"] for R in runs])
        ss = ci([R["targets"][tn]["site_specific"] for R in runs])
        ax.axhline(z[0], color="#d62728", ls=":", lw=1)
        ax.text(shots[0], z[0] + 0.1, "zero-shot", color="#d62728", fontsize=7)
        ax.axhline(ss[0], color="k", ls="-.", lw=1)
        ax.text(shots[0], ss[0] + 0.1, f"site-specific ({runs[0]['targets'][tn]['n_train_ue']} UEs)", fontsize=7)
        out[f"{tn}|zero"] = {k: ci([R["targets"][tn]["zero"][k] for R in runs]) for k in runs[0]["targets"][tn]["zero"]}
        out[f"{tn}|site"] = ss
        out[f"{tn}|net"] = {k: {m: ci([R["targets"][tn]["net"][k][m] for R in runs]) for m in ("wsr", "p5_sinr")}
                            for k in runs[0]["targets"][tn]["net"]}
        out[f"{tn}|cb"] = {k: {m: ci([R["targets"][tn]["cb_metrics"][k][m] for R in runs]) for m in ("logdet_serv", "cover")}
                           for k in runs[0]["targets"][tn]["cb_metrics"]}
        ax.set_xscale("log")
        ax.set_xticks(shots)
        ax.set_xticklabels([str(n) for n in shots])
        ax.minorticks_off()
        lo = min(z[0], min(min(v[1] for v in out[f"{tn}|{k}"]) for k, *_ in meth)) - 0.6
        ax.set_ylim(lo, 0)
        ax.set_xlabel("Labelled target UE locations $N_{\\mathrm{shot}}$")
        ax.set_ylabel("Mean gap to MRT (dB)")
        ax.set_title(f"Target {tn}")
    axs[1].legend(fontsize=6.3, loc="lower right")
    plt.tight_layout()
    plt.savefig(FIG / "fig_transfer.pdf", bbox_inches="tight")
    plt.close()
    return out


# ============================================================================ extras
def extras():
    out = {}
    for f in glob.glob("results/latency_*.pt"):
        R = torch.load(f, weights_only=False)
        fig, ax = plt.subplots(1, 1, figsize=(4.6, 3.3))
        cols = {16: "#1f77b4", 32: "#d62728", 64: "#2ca02c"}
        for N, row in R.items():
            for name, st in (("cfm", "o-"), ("diff", "s--")):
                x = [row[name][s]["lat_ms"] for s in row[name]]
                y = [row[name][s]["gap"] for s in row[name]]
                ax.plot(x, y, st, color=cols[N], label=f"{'CFM' if name == 'cfm' else 'Diffusion (DDIM)'}, $N_t$={N}")
                for s, xx, yy in zip(row[name], x, y):
                    if s in (1, 8, 5, 50):
                        ax.annotate(str(s), (xx, yy), fontsize=6, xytext=(2, 2), textcoords="offset points")
        ax.set_xscale("log")
        ax.set_xlabel("Inference latency per 128 links, $M$=8 (ms, CPU)")
        ax.set_ylabel("Mean gap to MRT (dB)")
        ax.legend(fontsize=6.3)
        plt.tight_layout()
        plt.savefig(FIG / "fig_latency.pdf", bbox_inches="tight")
        plt.close()
        out["latency"] = {N: {n: {s: v for s, v in row[n].items()} for n in row} for N, row in R.items()}
    ks = {}
    for f in glob.glob("results/ksweep_*.pt"):
        s = f.split("_")[1]
        ks[s] = torch.load(f, weights_only=False)
    if ks:
        out["ksweep"] = ks
        lines = []
        for s, R in sorted(ks.items(), key=lambda x: x[0], reverse=True):
            for K, row in R.items():
                cells = [s if K == min(R) else "", str(K)]
                for cbk in ("dft", "su", "cia"):
                    cells += [f"{row[cbk]['gap']:.2f}", f"{row[cbk]['wsr']:.2f}"]
                lines.append(" & ".join(cells) + " \\\\")
        (TAB / "tab_ksweep_rows.tex").write_text("\n".join(lines) + "\n")
    rb = {}
    for f in glob.glob("results/robust_*.pt"):
        s = f.split("_")[1]
        rb[s] = torch.load(f, weights_only=False)
    if rb:
        out["robust"] = rb
        conds = list(next(iter(rb.values())).keys())
        lines = []
        for c in conds:
            cells = [c.replace("^2", "$^2$").replace("%", "\\%")]
            for s in ("LOS-1", "BLK-1"):
                if s not in rb:
                    continue
                for n in ("SU-SIM+CFM", "CIA-SIM+MC-CFM"):
                    cells += [f"{rb[s][c][n]['gap']:.2f}", f"{rb[s][c][n]['wsr']:.2f}"]
            lines.append(" & ".join(cells) + " \\\\")
        (TAB / "tab_robust_rows.tex").write_text("\n".join(lines) + "\n")
    return out


if __name__ == "__main__":
    S = {"insite": insite(), "sweep": sweeps(), "transfer": transfer(), "extras": extras()}

    def conv(o):
        if isinstance(o, dict):
            return {str(k): conv(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)):
            return [conv(v) for v in o]
        if isinstance(o, (np.floating, np.integer)):
            return o.item()
        return o
    Path("results/summary.json").write_text(json.dumps(conv(S), indent=1))
    print("summary written")
