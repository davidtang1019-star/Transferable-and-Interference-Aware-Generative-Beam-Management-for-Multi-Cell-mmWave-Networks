import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, FancyArrowPatch
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})
C = {"ssb": "#2a6f97", "rs": "#c8553d", "data": "#6d597a", "fb": "#555555", "gen": "#e9c46a", "sched": "#90be6d"}

def box(ax, x, y, w, h, txt, fc, tc="white", fs=8.5, ec="none", r=0.02):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0.005,rounding_size={r}", fc=fc, ec=ec, lw=0.8))
    ax.text(x + w / 2, y + h / 2, txt, ha="center", va="center", color=tc, fontsize=fs)

def arrow(ax, x0, y0, x1, y1, c="#333333", ls="-", lw=1.0):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=9, color=c, lw=lw, ls=ls))

# ---------------- protocol timeline
fig, ax = plt.subplots(figsize=(10, 3.9))
ax.set_xlim(0, 100); ax.set_ylim(0, 40); ax.axis("off")
rows = {"BS 1": 31, "BS 2": 24, "BS 3": 17}
for name, y in rows.items():
    ax.text(1, y + 2, name, va="center", fontsize=9, weight="bold")
    x = 8
    for k in range(4):
        box(ax, x, y, 2.6, 4, "SSB" if k < 3 else "…", C["ssb"], fs=6.5); x += 2.9
    x = 40
    for k in range(4):
        box(ax, x, y, 2.6, 4, "RS" if k < 3 else "…", C["rs"], fs=6.5); x += 2.9
    for k in range(4):
        box(ax, 70 + 3.2 * k, y, 3.0, 4, "DATA", C["data"], fs=5.8)
y = 8
ax.text(1, y + 2, "UE", va="center", fontsize=9, weight="bold")
box(ax, 8, y, 11.3, 4, "measure serving +\nneighbour SSBs", "#dbe7f0", tc="black", fs=7)
box(ax, 21, y, 9, 4, "report $\\mathbf{Y}_u$\n(RSRP, $K\\!+\\!K_I$)", "#eeeeee", tc="black", fs=7)
box(ax, 40, y, 11.3, 4, "measure $M$\ncandidates", "#f4d9d3", tc="black", fs=7)
box(ax, 53, y, 9, 4, "report $M$ CQIs", "#eeeeee", tc="black", fs=7)
box(ax, 31.3, 16.5, 7.5, 19, "Stage II\nMC-CFM:\ncandidates\n+ leakage\nestimates", C["gen"], tc="black", fs=7)
box(ax, 63, 16.5, 6.2, 19, "Stage III\nbest-\nresponse\nscheduling\n(Xn)", C["sched"], tc="black", fs=7)
for x0, x1 in ((30, 31.3), (62, 63)):
    arrow(ax, x0, 10, x1 + 0.6, 16.5)
ax.annotate("", xy=(8, 38.5), xytext=(37.5, 38.5), arrowprops=dict(arrowstyle="<->", lw=0.8))
ax.text(22.7, 39.2, "Stage I: multi-cell probing ($K$ SSBs per cell, no extra airtime for neighbours)", ha="center", fontsize=7.5)
ax.annotate("", xy=(40, 1.5), xytext=(62, 1.5), arrowprops=dict(arrowstyle="<->", lw=0.8))
ax.text(51, 2.3, "candidate refinement ($M$ CSI-RS)", ha="center", fontsize=7.5)
ax.annotate("", xy=(70, 1.5), xytext=(83, 1.5), arrowprops=dict(arrowstyle="<->", lw=0.8))
ax.text(76.5, 2.3, "beam locking / data", ha="center", fontsize=7.5)
ax.annotate("", xy=(8, 0.0), xytext=(84, 0.0), arrowprops=dict(arrowstyle="-", lw=0.6, ls=":"))
ax.text(86, 20, "SSB period", rotation=90, va="center", fontsize=8)
plt.tight_layout(); fig.savefig("figs/fig_protocol.pdf", bbox_inches="tight"); fig.savefig("figs/fig_protocol.png", dpi=160, bbox_inches="tight")

# ---------------- framework block diagram
fig, ax = plt.subplots(figsize=(10, 4.6))
ax.set_xlim(0, 100); ax.set_ylim(0, 46); ax.axis("off")
box(ax, 1, 21, 15, 9, "Multi-cell report $\\mathbf{Y}_u$\n(serving + neighbour\nRSRP, quantised)", "#dbe7f0", tc="black", fs=7.5)
box(ax, 1, 6, 15, 9, "Site metadata $\\mathbf{m}$\n+ site offset $\\boldsymbol{\\delta}_\\mathcal{E}$", "#e6e6e6", tc="black", fs=7.5)
box(ax, 1, 33, 15, 11, "Probing codebooks\n$\\mathbf{C}_1,\\ldots,\\mathbf{C}_B$\n(SIM / IA-SIM,\njoint refinement)", "#cfe3d4", tc="black", fs=7.5)
arrow(ax, 8.5, 33, 8.5, 30)
# encoders
for i, (t, y) in enumerate((("shape enc. $f_{sh}$", 38.5), ("scale enc. $f_{sc}$", 33.5), ("interference enc. $f_{int}$", 28.5), ("site enc. $f_{site}$", 23.5))):
    box(ax, 22, y, 17, 4, t, "#5b8e7d", fs=7.5)
for y in (40.5, 35.5, 30.5):
    arrow(ax, 16, 25.5, 22, y)
arrow(ax, 16, 10.5, 22, 25.5)
box(ax, 43, 26, 9, 17, "FiLM\nfusion\n$\\mathbf{c}$", "#8d6a9f", fs=8)
for y in (40.5, 35.5, 30.5, 25.5):
    arrow(ax, 39, y, 43, min(max(y, 27), 42))
box(ax, 56, 26, 17, 17, "Vector field $\\mathbf{v}_\\theta$\n(FiLM blocks\n+ LoRA adapters)\nEuler, $N_{step}$ steps\n+ gain head $g_\\theta$", C["gen"], tc="black", fs=7.5)
arrow(ax, 52, 34.5, 56, 34.5)
box(ax, 77, 36, 19, 7, "serving link $(s(u),u)$:\n$M$ candidate beams", "#f4d9d3", tc="black", fs=7.5)
box(ax, 77, 26, 19, 8, "cross link $(b,v)$, $v$ in\nneighbour cell: direction\nsamples + gain $\\to$ INR", "#f4d9d3", tc="black", fs=7.5)
arrow(ax, 73, 38, 77, 39.5); arrow(ax, 73, 31, 77, 30)
box(ax, 56, 4, 43, 14, "Coordinated candidate scheduling (Alg. 2)\nmax  $\\sum_b \\omega_{u_b}\\log_2(1+\\widehat{SNR}_{u_b,m_b}/(1+\\sum_{i\\neq b}\\widehat{INR}_{i\\to u_b}))$\nbest response over (user, candidate) per cell; CQI of all $M$ candidates", C["sched"], tc="black", fs=7.5)
ax.plot([96, 98.5, 98.5], [39.5, 39.5, 30], color="#333333", lw=1.0)
ax.plot([96, 98.5], [30, 30], color="#333333", lw=1.0)
arrow(ax, 98.5, 30, 98.5, 18)
box(ax, 22, 4, 30, 14, "Transfer: multi-site pre-training\n+ Reptile meta-initialisation\n$\\to$ target: train LoRA, $\\boldsymbol{\\delta}_\\mathcal{E}$, gain head\nwith $N_{shot}$ samples", "#e6e6e6", tc="black", fs=7.5)
arrow(ax, 52, 11, 64, 26, ls="--")
plt.tight_layout(); fig.savefig("figs/fig_framework.pdf", bbox_inches="tight"); fig.savefig("figs/fig_framework.png", dpi=160, bbox_inches="tight")
print("ok")
