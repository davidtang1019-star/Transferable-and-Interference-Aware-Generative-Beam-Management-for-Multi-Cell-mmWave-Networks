"""Beam-management schemes evaluated at link and network level."""
import math

import numpy as np
import torch

from .core import (SysParams, MCCFM, MLPBeam, DiffusionBeam, train_codebook, dft_codebook, train_generator,
                   cand_gain, mrt_gain, rsrp_db, logdet_cov, _shape_norm)
from .pipeline import (B, SiteData, LinkSet, measure, link_inputs, aux_dim, gen_candidates, beam_search, srs_beam,
                       schedule_drop, true_sinr)


def codebook_set(sd: SiteData, sp, kind, seed=0, epochs=60, lam_int=0.25, lam_cov=0.05, rel_db=10.0, weighted=True):
    if kind == "cia":  # conditional interference-aware: start from SU-SIM, then block-coordinate update
        base = codebook_set(sd, sp, "su", seed=seed, epochs=epochs, lam_cov=lam_cov)
        out = list(base)
        tr = sd.idx["train"]
        for b in range(B):
            s = sd.serv[tr]
            gs = sd.G[s, tr]
            keep = (s != b) & (sd.G[b, tr] >= gs * 10 ** (-rel_db / 10))
            v = tr[keep]
            ys = torch.zeros(len(v), sp.K)
            for i in range(B):
                mi = sd.serv[v] == i
                if mi.any():
                    ys[mi] = rsrp_db(sd.H[i, v[mi]], out[i], sp, noisy=False, quantize=False)
            wi = sd.G[b, v] / sd.G[sd.serv[v], v]
            w, _ = train_codebook(sd.h_serv(b), sd.H[b, v], sp, mode="ia", epochs=epochs, seed=seed + b,
                                  lam_int=lam_int, lam_cov=lam_cov, w_int=wi if weighted else None, y_int_serv=ys,
                                  init=out[b], lr=1e-2)
            out[b] = w
        return out
    cbs = []
    for b in range(B):
        if kind == "dft":
            cbs.append(dft_codebook(sp.n_ant, sp.K))
        else:
            hs = sd.h_serv(b)
            hi, wi = sd.h_int(b, rel_db=rel_db, return_w=True)
            w, _ = train_codebook(hs, hi, sp, mode=kind, epochs=epochs, seed=seed + b, lam_int=lam_int,
                                  lam_cov=lam_cov, w_int=wi if weighted else None)
            cbs.append(w)
    return cbs


@torch.no_grad()
def codebook_metrics(sd, cbs, sp, split="test"):
    out = {"logdet_serv": [], "logdet_int": [], "cover": []}
    for b in range(B):
        for key, h in (("logdet_serv", sd.h_serv(b, split)), ("logdet_int", sd.h_int(b, split))):
            if h.shape[0] < sp.K + 2:
                continue
            y = rsrp_db(h, cbs[b], sp, noisy=False, quantize=False)
            out[key].append(float(logdet_cov(_shape_norm(y))))
        # fraction of UEs (serving + interfered) whose best probing beam is >= 10 dB above noise
        h = torch.cat([sd.h_serv(b, split), sd.h_int(b, split)])
        g = (cand_gain(h, cbs[b].T[None].expand(h.shape[0], -1, -1))).amax(1)
        out["cover"].append(float((sp.pt * g / sp.noise >= 10.0).float().mean()))
    return {k: float(np.mean(v)) for k, v in out.items()}


class GenScheme:
    """Codebook + generator (CFM, MLP or diffusion)."""

    def __init__(self, name, cbs, model, aux_mode, steps=8, use_meta=False):
        self.name, self.cbs, self.model, self.aux_mode, self.steps, self.use_meta = name, cbs, model, aux_mode, steps, use_meta

    @torch.no_grad()
    def prepare(self, sd, users, sp, M, noisy=True):
        """Generate, for every (BS b, UE in users) link, M beam samples and a gain estimate."""
        Y = measure(sd, self.cbs, users, sp, noisy=noisy)
        n = len(users)
        bl = torch.arange(B).repeat_interleave(n)
        pos = torch.arange(n).repeat(B)
        W, lg = gen_candidates(self.model, sd, self.cbs, sp, bl, users[pos], M, self.steps, self.aux_mode,
                               noisy, self.use_meta, Y=Y, upos=pos)
        Mg = W.shape[1]
        return {"W": W.view(B, n, Mg, -1), "snr_hat": (10 ** lg).view(B, n), "Y": Y}


def make_gen(kind, sp, aux_mode, meta_dim=0, n_sites=0, width=256):
    ad = aux_dim(sp, aux_mode)
    if kind == "cfm":
        return MCCFM(sp.n_ant, sp.K, ad, meta_dim, n_sites, width=width)
    if kind == "mlp":
        return MLPBeam(sp.n_ant, sp.K, ad, width=width)
    if kind == "diff":
        return DiffusionBeam(sp.n_ant, sp.K, ad, width=width)
    raise ValueError(kind)


def fit_gen(model, sites, cbs_per_site, sp, aux_mode, epochs=40, lr=1e-3, bs=256, pt_range=(10.0, 40.0),
            serving_only=False, use_meta=False, params=None, subset=None, seed=0, verbose=False, max_links=None):
    ls = LinkSet(sites, cbs_per_site, sp, "train", aux_mode, serving_only=serving_only, subset=subset, seed=seed,
                 max_links=max_links)
    rng = np.random.default_rng(seed)

    def resample(idx):
        pt = float(rng.uniform(*pt_range)) if pt_range else sp.pt_dbm
        ls.sp = sp.copy(pt_dbm=pt)
        sh, gl, ax = ls.resample(idx)
        # gain target must follow the drawn transmit power
        lg = ls.log_gain[idx] + (pt - sp.pt_dbm) / 10.0
        return sh, gl, ax, lg

    class Wrap(torch.nn.Module):  # adapts the resample signature to train_generator
        pass

    n = len(ls)
    opt_params = params if params is not None else [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.AdamW(opt_params, lr=lr, weight_decay=1e-4)
    steps_per = max(int(math.ceil(n / bs)), 1)
    total = max(epochs * steps_per, 1)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=total)
    hist = []
    model.train()
    torch.manual_seed(seed)
    for ep in range(epochs):
        perm = torch.randperm(n)
        tot = 0.0
        for s in range(steps_per):
            idx = perm[s * bs:(s + 1) * bs]
            if len(idx) < 2:
                continue
            sh, gl, ax, lg = resample(idx)
            meta = ls.meta[idx] if use_meta else None
            sid = ls.site_idx[idx] if use_meta else None
            l = model.loss(sh, gl, ax, ls.target[idx], lg, meta, sid)
            opt.zero_grad()
            l.backward()
            torch.nn.utils.clip_grad_norm_(opt_params, 1.0)
            opt.step()
            sched.step()
            tot += float(l)
        hist.append(tot / steps_per)
        if verbose and (ep % 10 == 0 or ep == epochs - 1):
            print(f"    ep {ep} loss {hist[-1]:.4f} (links={n})", flush=True)
    model.eval()
    return hist, ls


# ----------------------------------------------------------------------------- link-level evaluation
@torch.no_grad()
def link_eval(scheme, sd, sp, M, split="test", noisy=True, max_users=1500):
    users = sd.idx[split][:max_users]
    P = scheme.prepare(sd, users, sp, M, noisy)
    s = sd.serv[users]
    n = len(users)
    W = P["W"][s, torch.arange(n)]  # serving-link candidates (n,M,N)
    h = sd.H[s, users]
    gap = 10 * torch.log10(cand_gain(h, W).amax(1) / mrt_gain(h))
    # interference-link direction/gain estimation error: leakage of a random probe beam
    errs, strong = [], []
    for b in range(B):
        m = (s != b) & (sd.G[b, users] >= sd.G[s, users] * 1e-3)
        if m.sum() == 0:
            continue
        hb = sd.H[b, users[m]]
        Wd = P["W"][b, m]  # (k,Ms,N)
        probe = torch.exp(1j * 2 * math.pi * torch.rand(hb.shape)).to(torch.complex64) / math.sqrt(sp.n_ant)
        # structured probes: steer toward random directions within the sector
        u = torch.rand(hb.shape[0]) * 2 - 1
        nn_ = torch.arange(sp.n_ant).float()
        probe = (torch.exp(1j * math.pi * u[:, None] * nn_) / math.sqrt(sp.n_ant)).to(torch.complex64)
        true = sp.pt * (hb.conj() * probe).sum(-1).abs() ** 2 / sp.noise
        est = P["snr_hat"][b, m] * ((Wd.conj() * probe[:, None]).sum(-1).abs() ** 2).mean(1)
        errs.append(10 * torch.log10((est + 1e-3) / (true + 1e-3)))
        strong.append((sd.G[b, users[m]] >= sd.G[s[m], users[m]] * 0.1))
    e = torch.cat(errs) if errs else torch.zeros(1)
    st = torch.cat(strong) if strong else torch.zeros(1, dtype=torch.bool)
    return {"gap": gap, "leak_err_db": e, "leak_strong": st}


# ----------------------------------------------------------------------------- network-level evaluation
def _weights(sd, users, sp):
    s = sd.serv[users]
    snr = sp.pt * sd.G[s, users] / sp.noise
    w = 1.0 / torch.log2(1 + snr)
    return w


@torch.no_grad()
def network_eval(sd, sp, schemes, n_drops=200, U=4, M=8, seed=0, sched_modes=("unc", "coord"), cqi_all=True,
                 me=4, extra=None):
    """Returns dict[scheme][mode] -> dict of arrays (per scheduled UE: sinr, rate, weight)."""
    g = torch.Generator().manual_seed(seed)
    test = sd.idx["test"]
    pools = [test[sd.serv[test] == b] for b in range(B)]
    drops = [torch.stack([p[torch.randperm(len(p), generator=g)[:U]] for p in pools]) for _ in range(n_drops)]
    users_all = torch.unique(torch.cat([d.reshape(-1) for d in drops]))
    pos_of = {int(u): i for i, u in enumerate(users_all.tolist())}
    wts_all = _weights(sd, users_all, sp)
    wts_all = wts_all / wts_all.mean()
    res = {}
    torch.manual_seed(seed)
    for sc in schemes:
        name = sc.name if hasattr(sc, "name") else sc
        P = prepare_any(sc, sd, users_all, sp, M)
        res[name] = {}
        for mode in sched_modes:
            acc = {"sinr": [], "w": [], "rate": []}
            for d in drops:
                choice, Wc, Hc, wt = _drop(sd, sp, P, d, pos_of, wts_all, mode, cqi_all, me)
                sinr = true_sinr(choice, Wc, Hc, sp)
                acc["sinr"].append(sinr)
                acc["w"].append(torch.stack([wt[b, choice[b, 0]] for b in range(B)]))
            sinr = torch.cat(acc["sinr"])
            w = torch.cat(acc["w"])
            res[name][mode] = {"sinr_db": (10 * torch.log10(sinr)).numpy(), "w": w.numpy()}
    return res


def prepare_any(sc, sd, users, sp, M):
    n = len(users)
    s = sd.serv[users]
    if isinstance(sc, GenScheme):
        P = sc.prepare(sd, users, sp, M)
        return {"W": P["W"], "snr_hat": P["snr_hat"], "kind": "gen"}
    if sc == "beamsearch":
        W = torch.zeros(B, n, M, sp.n_ant, dtype=torch.complex64)
        snr_hat = torch.zeros(B, n)
        for b in range(B):
            _, Wq, y1 = beam_search(sd.H[b, users], sp.K, M, sp)
            W[b] = Wq
            snr_hat[b] = 10 ** ((y1.amax(1) - 30 - 10 * math.log10(sp.noise)) / 10)
        return {"W": W, "snr_hat": snr_hat, "kind": "bs"}
    if sc == "srs":
        W = torch.zeros(B, n, 1, sp.n_ant, dtype=torch.complex64)
        Hh = torch.zeros(B, n, sp.n_ant, dtype=torch.complex64)
        for b in range(B):
            w, hh = srs_beam(sd.H[b, users], sp)
            W[b], Hh[b] = w, hh
        return {"W": W, "Hhat": Hh, "kind": "srs"}
    if sc == "genie":
        W = torch.exp(1j * torch.angle(sd.H[:, users])) / math.sqrt(sp.n_ant)
        return {"W": W[:, :, None, :].to(torch.complex64), "Hhat": sd.H[:, users], "kind": "srs"}
    raise ValueError(sc)


def _drop(sd, sp, P, d, pos_of, wts_all, mode, cqi_all, me):
    """Build estimated S/X tensors for one drop and schedule."""
    Bn, U = d.shape
    idx = torch.tensor([[pos_of[int(u)] for u in row] for row in d.tolist()])  # (B,U) positions
    Mc = P["W"].shape[2]
    Wc, Hc = [], []
    S_est = torch.zeros(Bn, U, Mc)
    X_est = torch.zeros(Bn, U, Mc, Bn, U)
    wt = wts_all[idx]
    for b in range(Bn):
        users = d[b]
        Wb = P["W"][b, idx[b]]  # (U,Mc,N): candidates of the serving link (serving cell = b)
        Wc.append(Wb)
        Hc.append([sd.H[i, users] for i in range(Bn)])
        g = cand_gain(sd.H[b, users], Wb)
        snr = sp.pt * g / sp.noise
        # CQI report: measured with 0.5 dB error and 1 dB quantisation
        meas = torch.round(10 * torch.log10(snr + 1e-9) + 0.5 * torch.randn_like(snr))
        if cqi_all or P["kind"] != "gen":
            S_est[b] = 10 ** (meas / 10)
        else:  # only best index + its CQI reported; other candidates unusable
            best = meas.argmax(1)
            S_est[b] = 0.0
            S_est[b, torch.arange(U), best] = 10 ** (meas[torch.arange(U), best] / 10)
    for b in range(Bn):
        for i in range(Bn):
            if i == b:
                continue
            v = idx[i]  # victims served by cell i
            Wb = Wc[b].reshape(-1, sp.n_ant)  # (U*Mc,N)
            if P["kind"] == "srs":
                hh = P["Hhat"][b, v]  # (U,N)
                x = sp.pt * ((hh.conj() @ Wb.T).abs() ** 2).T / sp.noise  # (U*Mc,U)
            else:
                D = P["W"][b, v][:, :me]  # (U,me,N) direction samples of link (b -> victim)
                corr = (torch.einsum("vmn,kn->kvm", D.conj(), Wb).abs() ** 2).mean(-1)  # (U*Mc,U)
                x = corr * P["snr_hat"][b, v][None]
            X_est[b, :, :, i, :] = x.view(U, Mc, U)
    if mode == "genie":
        for b in range(Bn):
            S_est[b] = sp.pt * cand_gain(sd.H[b, d[b]], Wc[b]) / sp.noise
            for i in range(Bn):
                if i != b:
                    Wb = Wc[b].reshape(-1, sp.n_ant)
                    X_est[b, :, :, i, :] = (sp.pt * ((sd.H[b, d[i]].conj() @ Wb.T).abs() ** 2).T / sp.noise).view(U, Mc, U)
        mode = "coord"
    choice = schedule_drop(S_est, X_est, wt, 1.0, mode)
    return choice, Wc, Hc, wt


def summarize(entry, edge_q=0.75):
    s = entry["sinr_db"]
    w = entry["w"]
    rate = np.log2(1 + 10 ** (s / 10))
    edge = w >= np.quantile(w, edge_q)
    return {"wsr": float(np.mean(w * rate) * 3), "sum_rate": float(np.mean(rate) * 3), "mean_sinr": float(np.mean(s)),
            "p5_sinr": float(np.percentile(s, 5)), "outage": float(np.mean(s < 0.0)),
            "edge_rate": float(np.mean(rate[edge]))}
