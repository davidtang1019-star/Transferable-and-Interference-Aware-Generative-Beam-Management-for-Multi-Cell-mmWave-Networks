"""Adapter: build a multi-cell site dictionary (as produced by sites.build_site_dataset) from DeepMIMO.

Not exercised in the paper's experiments (DeepMIMO was not reachable from the authors' compute environment);
provided so that all experiments can be repeated on ray-traced scenarios such as O1_28 / O1B_28.
Requires the reference package `gen_ssbf` (Zhao, Wang, Liu) and DeepMIMO v4.
"""
import numpy as np


def site_from_deepmimo(scenario, scenarios_dir, tx_indices=(0, 1, 2), n_antennas=32, meta=None, **kw):
    from gen_ssbf.data import load_deepmimo_channels
    H = []
    for t in tx_indices:
        h = load_deepmimo_channels(scenario, scenarios_dir, n_antennas=n_antennas, tx_indices=(t,), **kw)
        H.append(h.numpy())
    n = min(x.shape[0] for x in H)  # NOTE: assumes identical UE ordering/validity across BSs; verify per scenario
    H = np.stack([x[:n] for x in H], 0).astype(np.complex64)
    mrt = np.abs(H).sum(-1) ** 2 / n_antennas
    return {"H": H, "serving": mrt.argmax(0), "los": np.zeros_like(mrt, dtype=bool), "xy": np.zeros((n, 2)),
            "meta": np.zeros(8, np.float32) if meta is None else np.asarray(meta, np.float32), "name": scenario}
