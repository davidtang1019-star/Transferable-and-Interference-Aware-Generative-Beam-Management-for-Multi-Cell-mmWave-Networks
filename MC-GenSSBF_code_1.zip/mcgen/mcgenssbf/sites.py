"""Site-specific multi-cell mmWave channel generator.

Each *site* is a fixed 2-D urban layout (buildings = axis-aligned rectangles,
point scatterers, three BSs with ULAs). Channels are produced by a deterministic
2.5-D ray model: LoS + first-order specular wall reflections (image method)
+ single-bounce point scatterers, each path checked for blockage against the
building footprints. Path gains follow free-space loss at 28 GHz times a
reflection/scattering loss; phases follow the geometric path length, so the
small-scale channel is a deterministic function of the UE location and of the
site geometry (as in ray-traced datasets such as DeepMIMO).
"""
import math
from dataclasses import dataclass, field

import numpy as np

C0 = 3e8


@dataclass
class SiteConfig:
    name: str
    seed: int
    n_buildings: int = 6
    n_scatterers: int = 8
    bs_height: tuple = (10.0, 10.0, 10.0)
    isd: float = 90.0               # inter-site distance of the 3 BSs (m)
    street_angle_deg: float = 0.0   # rotation of the building grid
    refl_db: tuple = (-6.0, -12.0)  # range of wall reflection loss (dB)
    scat_db: tuple = (-18.0, -25.0) # range of point-scatterer loss (dB)
    blocker_bias: float = 0.0       # >0 pulls buildings toward BSs (more blockage)
    family: str = "los"


@dataclass
class Site:
    cfg: SiteConfig
    bs_xy: np.ndarray               # (B,2)
    bs_h: np.ndarray                # (B,)
    bs_boresight: np.ndarray        # (B,) rad, array normal direction
    rects: np.ndarray               # (R,4) xmin,ymin,xmax,ymax (in rotated frame handled already)
    scat_xy: np.ndarray             # (S,2)
    scat_gain: np.ndarray           # (S,) linear amplitude factor
    wall_gain: np.ndarray           # (R,) linear amplitude factor
    ue_xy: np.ndarray = None        # (U,2)
    meta: np.ndarray = None         # metadata vector


def _rot(xy, ang):
    c, s = math.cos(ang), math.sin(ang)
    return xy @ np.array([[c, -s], [s, c]]).T


def make_site(cfg: SiteConfig, ue_spacing=1.0):
    rng = np.random.default_rng(cfg.seed)
    B = 3
    # BSs on an equilateral triangle, each sector pointing to the centroid
    r = cfg.isd / math.sqrt(3.0)
    ang0 = rng.uniform(0, 2 * math.pi)
    bs_xy = np.stack([[r * math.cos(ang0 + 2 * math.pi * b / 3), r * math.sin(ang0 + 2 * math.pi * b / 3)] for b in range(B)])
    boresight = np.arctan2(-bs_xy[:, 1], -bs_xy[:, 0]) + rng.uniform(-0.2, 0.2, size=B)
    ang = math.radians(cfg.street_angle_deg)
    bs_xy = _rot(bs_xy, -ang)
    boresight = boresight - ang
    bs_h = np.asarray(cfg.bs_height, dtype=float)

    # buildings: random rectangles inside the triangle hull, avoiding BS sites
    rects = []
    tries = 0
    while len(rects) < cfg.n_buildings and tries < 5000:
        tries += 1
        w, h = rng.uniform(6, 16), rng.uniform(6, 16)
        if cfg.blocker_bias > 0 and rng.random() < cfg.blocker_bias:
            b = rng.integers(B)
            c = bs_xy[b] * rng.uniform(0.55, 0.8)  # close in front of a BS
        else:
            c = rng.uniform(-0.75 * r, 0.75 * r, size=2)
        # rotate building centre by street angle (axis-aligned in rotated frame)
        rect = np.array([c[0] - w / 2, c[1] - h / 2, c[0] + w / 2, c[1] + h / 2])
        if np.min(np.linalg.norm(bs_xy - c, axis=1)) < 14:
            continue
        ok = True
        for q in rects:
            if not (rect[2] + 3 < q[0] or q[2] + 3 < rect[0] or rect[3] + 3 < q[1] or q[3] + 3 < rect[1]):
                ok = False
                break
        if ok:
            rects.append(rect)
    rects = np.array(rects).reshape(-1, 4)
    scat_xy = rng.uniform(-0.8 * r, 0.8 * r, size=(cfg.n_scatterers, 2))
    scat_gain = 10 ** (rng.uniform(cfg.scat_db[1], cfg.scat_db[0], size=cfg.n_scatterers) / 20)
    wall_gain = 10 ** (rng.uniform(cfg.refl_db[1], cfg.refl_db[0], size=len(rects)) / 20)

    site = Site(cfg, bs_xy, bs_h, boresight, rects, scat_xy, scat_gain, wall_gain)
    # UE grid inside triangle (shrunk) and outside buildings
    xs = np.arange(-r, r, ue_spacing)
    gx, gy = np.meshgrid(xs, xs)
    pts = np.stack([gx.ravel(), gy.ravel()], 1)
    inside = _in_triangle(pts, site.bs_xy * 0.92)
    for q in rects:
        inside &= ~((pts[:, 0] > q[0] - 0.5) & (pts[:, 0] < q[2] + 0.5) & (pts[:, 1] > q[1] - 0.5) & (pts[:, 1] < q[3] + 0.5))
    inside &= np.min(np.linalg.norm(pts[:, None, :] - site.bs_xy[None], axis=2), axis=1) > 8
    site.ue_xy = pts[inside]
    area = (r * 1.5) ** 2 * math.sqrt(3) / 4 * 3
    bdens = float(np.sum((rects[:, 2] - rects[:, 0]) * (rects[:, 3] - rects[:, 1]))) / area if len(rects) else 0.0
    site.meta = np.array([bs_h.mean() / 10.0, bdens * 5.0, len(rects) / 8.0, cfg.n_scatterers / 10.0,
                          math.cos(2 * ang), math.sin(2 * ang), float(np.mean(20 * np.log10(wall_gain))) / -10.0,
                          cfg.blocker_bias], dtype=np.float32)
    return site


def _in_triangle(p, tri):
    def sgn(p, a, b):
        return (p[:, 0] - b[0]) * (a[1] - b[1]) - (a[0] - b[0]) * (p[:, 1] - b[1])
    d1, d2, d3 = sgn(p, tri[0], tri[1]), sgn(p, tri[1], tri[2]), sgn(p, tri[2], tri[0])
    neg = (d1 < 0) | (d2 < 0) | (d3 < 0)
    pos = (d1 > 0) | (d2 > 0) | (d3 > 0)
    return ~(neg & pos)


def _seg_blocked(p0, p1, rects, skip=-1):
    """p0:(N,2) p1:(N,2). True if segment crosses any rect (Liang-Barsky)."""
    n = p0.shape[0]
    blocked = np.zeros(n, dtype=bool)
    d = p1 - p0
    for i, q in enumerate(rects):
        if i == skip:
            continue
        t0 = np.zeros(n)
        t1 = np.ones(n)
        ok = np.ones(n, dtype=bool)
        for pk, qk in ((-d[:, 0], p0[:, 0] - (q[0] + 1e-6)), (d[:, 0], (q[2] - 1e-6) - p0[:, 0]),
                       (-d[:, 1], p0[:, 1] - (q[1] + 1e-6)), (d[:, 1], (q[3] - 1e-6) - p0[:, 1])):
            par = np.abs(pk) < 1e-12
            ok &= ~(par & (qk < 0))
            with np.errstate(divide="ignore", invalid="ignore"):
                rr = np.where(par, 0.0, qk / np.where(par, 1.0, pk))
            neg = (pk < 0) & ~par
            pos = (pk > 0) & ~par
            t0 = np.where(neg, np.maximum(t0, rr), t0)
            t1 = np.where(pos, np.minimum(t1, rr), t1)
        blocked |= ok & (t0 < t1)
    return blocked


def _walls(rects):
    """Return list of walls: (rect_idx, axis, coord, lo, hi, outward_sign)."""
    walls = []
    for i, q in enumerate(rects):
        walls += [(i, 0, q[0], q[1], q[3], -1), (i, 0, q[2], q[1], q[3], +1),
                  (i, 1, q[1], q[0], q[2], -1), (i, 1, q[3], q[0], q[2], +1)]
    return walls


def site_paths(site: Site, b: int, ue_xy=None, fc=28e9):
    """Return per-UE path lists for BS b: (amp complex (U,P), aod (U,P)) with zero-padded invalid paths."""
    lam = C0 / fc
    ue = site.ue_xy if ue_xy is None else ue_xy
    U = ue.shape[0]
    bs = site.bs_xy[b]
    dh = site.bs_h[b] - 1.5
    amps, aods = [], []

    def add(path_len2d, dep_point, gain, valid):
        d3 = np.sqrt(path_len2d ** 2 + dh ** 2)
        a = gain * lam / (4 * math.pi * d3) * np.exp(-1j * 2 * math.pi * d3 / lam)
        v = dep_point - bs
        az = np.arctan2(v[..., 1], v[..., 0]) - site.bs_boresight[b]
        az = (az + np.pi) % (2 * np.pi) - np.pi
        valid = valid & (np.abs(az) < np.pi / 2 * 0.98)  # front half-plane of the panel
        amps.append(np.where(valid, a, 0.0))
        aods.append(np.where(valid, az, 0.0))

    # LoS
    bsN = np.broadcast_to(bs, ue.shape)
    blocked = _seg_blocked(bsN, ue, site.rects)
    add(np.linalg.norm(ue - bs, axis=1), ue, 1.0, ~blocked)
    # first-order wall reflections (image method)
    for (ri, ax, c, lo, hi, sgn) in _walls(site.rects):
        if (bs[ax] - c) * sgn <= 0:  # BS must be on outward side of wall
            continue
        img = bs.copy()
        img[ax] = 2 * c - bs[ax]
        on_side = (ue[:, ax] - c) * sgn > 0
        denom = ue[:, ax] - img[ax]
        with np.errstate(divide="ignore", invalid="ignore"):
            t = (c - img[ax]) / denom
        hit = img[None, :] + t[:, None] * (ue - img[None, :])
        oth = 1 - ax
        valid = on_side & (t > 0) & (t < 1) & (hit[:, oth] > lo) & (hit[:, oth] < hi)
        hit = np.where(valid[:, None], hit, ue)
        valid &= ~_seg_blocked(bsN, hit, site.rects, skip=ri) & ~_seg_blocked(hit, ue, site.rects, skip=ri)
        add(np.linalg.norm(ue - img, axis=1), hit, -site.wall_gain[ri], valid)
    # point scatterers (single bounce, distance product law approximated)
    for s in range(site.scat_xy.shape[0]):
        sp = site.scat_xy[s]
        d1 = np.linalg.norm(sp - bs)
        d2 = np.linalg.norm(ue - sp, axis=1)
        spN = np.broadcast_to(sp, ue.shape)
        valid = ~_seg_blocked(bsN, spN, site.rects) & ~_seg_blocked(spN, ue, site.rects)
        add(d1 + d2, spN, site.scat_gain[s] * np.ones(U), valid)
    return np.stack(amps, 1), np.stack(aods, 1)


def ula_channels(amps, aods, n_ant):
    n = np.arange(n_ant)
    a = np.exp(1j * math.pi * np.sin(aods)[..., None] * n)  # (U,P,N)
    return (amps[..., None] * a).sum(1)  # (U,N), conj convention: y = h^H w


def build_site_dataset(site: Site, n_ant=32, max_ues=None, seed=0):
    """Channels H[b] (U,N) from every BS to every UE, serving cell and LoS flags."""
    H = []
    los = []
    for b in range(3):
        amps, aods = site_paths(site, b)
        H.append(ula_channels(amps, aods, n_ant).astype(np.complex64))
        los.append(np.abs(amps[:, 0]) > 0)
    H = np.stack(H, 0)  # (3,U,N)
    mrt = (np.abs(H).sum(-1) ** 2) / n_ant  # MRT gain per link
    serving = np.argmax(mrt, 0)
    ok = mrt.max(0) > 1e-16  # drop dead locations
    idx = np.where(ok)[0]
    rng = np.random.default_rng(seed)
    rng.shuffle(idx)
    if max_ues is not None:
        idx = idx[:max_ues]
    return {
        "H": H[:, idx],
        "serving": serving[idx],
        "los": np.stack(los, 0)[:, idx],
        "xy": site.ue_xy[idx],
        "meta": site.meta,
        "name": site.cfg.name,
    }


def default_sites():
    """Eight training/validation sites + held-out targets, two families."""
    cfgs = []
    k = 0
    for fam, nb, ns, bias, refl in (("los", 5, 8, 0.0, (-6.0, -10.0)), ("blk", 9, 12, 0.6, (-8.0, -14.0))):
        for j in range(5):
            cfgs.append(SiteConfig(
                name=f"{fam.upper()}-{j+1}", seed=100 + k, n_buildings=nb + (j % 3), n_scatterers=ns + 2 * (j % 2),
                bs_height=tuple(float(x) for x in np.random.default_rng(200 + k).uniform(6, 15, 3)),
                isd=float(np.random.default_rng(300 + k).uniform(80, 110)),
                street_angle_deg=float(np.random.default_rng(400 + k).uniform(0, 90)),
                refl_db=refl, blocker_bias=bias, family=fam))
            k += 1
    return cfgs
