"""Per-site data handling, link-sample construction, scheme evaluation and
multi-cell multi-user scheduling."""
import math

import numpy as np
import torch

from .core import (SysParams, rsrp_db, quantize_neighbour, link_features, mrt_target, mrt_gain,
                   cand_gain, dft_codebook, steer, beam_gain)

B = 3


class SiteData:
    def __init__(self, d, site_id=0, split_seed=7, fr=(0.6, 0.2)):
        self.H = torch.from_numpy(d["H"])            # (3,U,N)
        self.serv = torch.from_numpy(d["serving"]).long()
        self.meta = torch.from_numpy(d["meta"]).float()
        self.name = d["name"]
        self.site_id = site_id
        self.xy = d["xy"]
        U = self.H.shape[1]
        rng = np.random.default_rng(split_seed)
        perm = rng.permutation(U)
        a, b = int(fr[0] * U), int((fr[0] + fr[1]) * U)
        self.idx = {"train": torch.from_numpy(perm[:a]), "val": torch.from_numpy(perm[a:b]),
                    "test": torch.from_numpy(perm[b:])}
        self.G = mrt_gain(self.H)                      # (3,U)

    def bs_meta(self, b):
        return self.meta

    def h_serv(self, b, split="train"):
        i = self.idx[split]
        i = i[self.serv[i] == b]
        return self.H[b, i]

    def h_int(self, b, split="train", rel_db=10.0, return_w=False):
        """Channels from BS b to neighbour-cell UEs that receive interference within rel_db of their
        serving power (the interference subspace of cell b); optional weights = relative interference power."""
        i = self.idx[split]
        s = self.serv[i]
        g_s = self.G[s, i]
        keep = (s != b) & (self.G[b, i] >= g_s * 10 ** (-rel_db / 10))
        if return_w:
            return self.H[b, i[keep]], (self.G[b, i[keep]] / g_s[keep])
        return self.H[b, i[keep]]

    def links(self, split="train", rel_db=30.0, serving_only=False):
        """Return (b, u) pairs of relevant links."""
        i = self.idx[split]
        bs, us = [], []
        for b in range(B):
            keep = self.serv[i] == b
            if not serving_only:
                keep = keep | (self.G[b, i] >= self.G[self.serv[i], i] * 10 ** (-rel_db / 10))
            bs.append(torch.full((int(keep.sum()),), b))
            us.append(i[keep])
        return torch.cat(bs), torch.cat(us)


def measure(sd: SiteData, cbs, users, sp: SysParams, noisy=True):
    """RSRP reports of `users` on all cells' codebooks -> (3,n,K) dBm with neighbour quantisation."""
    Y = torch.stack([rsrp_db(sd.H[b, users], cbs[b], sp, noisy=noisy) for b in range(B)], 0)
    if noisy:
        s = sd.serv[users]
        ys_max = Y[s, torch.arange(len(users))].amax(-1)
        for b in range(B):
            nb = s != b
            if nb.any():
                Y[b, nb] = quantize_neighbour(Y[b, nb], ys_max[nb], sp)
    return Y


def link_inputs(Y, bl, ul_pos, sp, aux_mode="full"):
    """Y: (3,n,K) reports; bl: BS of each link; ul_pos: position of the UE inside Y."""
    prim = Y[bl, ul_pos]
    if aux_mode == "none":
        aux = None
    else:
        aux = torch.stack([Y[(bl + 1) % B, ul_pos], Y[(bl + 2) % B, ul_pos]], 1)
    return link_features(prim, aux, sp, aux_mode)


def aux_dim(sp, aux_mode):
    return {"none": 0, "full": 2 * sp.K, "stats": 6}[aux_mode]


class LinkSet:
    """Training set of links for one or more sites with on-the-fly RSRP resampling."""

    def __init__(self, sites, cbs_per_site, sp, split="train", aux_mode="full", serving_only=False,
                 max_links=None, seed=0, subset=None):
        self.sites, self.cbs, self.sp, self.aux_mode = sites, cbs_per_site, sp, aux_mode
        rows = []
        g = torch.Generator().manual_seed(seed)
        for k, sd in enumerate(sites):
            bl, ul = sd.links(split, serving_only=serving_only)
            if subset is not None:  # few-shot: keep only links of the first `subset` UEs
                users = sd.idx[split][torch.randperm(len(sd.idx[split]), generator=g)[:subset]]
                m = torch.isin(ul, users)
                bl, ul = bl[m], ul[m]
            rows.append(torch.stack([torch.full_like(bl, k), bl, ul], 1))
        self.rows = torch.cat(rows, 0)
        if max_links is not None and self.rows.shape[0] > max_links:
            self.rows = self.rows[torch.randperm(self.rows.shape[0], generator=g)[:max_links]]
        k, b, u = self.rows.T
        self.target = torch.stack([mrt_target(self.sites[kk].H[bb, uu][None])[0] for kk, bb, uu in self.rows.tolist()]) \
            if self.rows.shape[0] < 0 else self._targets()
        self.log_gain = torch.stack([torch.log10(sp.pt * self.sites[kk].G[bb, uu] / sp.noise) for kk, bb, uu in
                                     self.rows.tolist()]) if self.rows.shape[0] < 0 else self._gains()
        self.meta = torch.stack([self.sites[kk].bs_meta(bb) for kk, bb in self.rows[:, :2].tolist()]) \
            if len(self.rows) else None
        self.site_idx = torch.tensor([self.sites[kk].site_id for kk in self.rows[:, 0].tolist()])

    def _targets(self):
        out = []
        for k, sd in enumerate(self.sites):
            m = self.rows[:, 0] == k
            out.append((m, mrt_target(sd.H[self.rows[m, 1], self.rows[m, 2]])))
        t = torch.zeros(self.rows.shape[0], 2, self.sites[0].H.shape[-1])
        for m, v in out:
            t[m] = v
        return t

    def _gains(self):
        t = torch.zeros(self.rows.shape[0])
        for k, sd in enumerate(self.sites):
            m = self.rows[:, 0] == k
            t[m] = torch.log10(self.sp.pt * sd.G[self.rows[m, 1], self.rows[m, 2]] / self.sp.noise)
        return t

    def resample(self, idx, noisy=True):
        r = self.rows[idx]
        sh = torch.zeros(len(idx), self.sp.K)
        gl = torch.zeros(len(idx), 2)
        ax = torch.zeros(len(idx), aux_dim(self.sp, self.aux_mode))
        for k, sd in enumerate(self.sites):
            m = r[:, 0] == k
            if not m.any():
                continue
            users, pos = torch.unique(r[m, 2], return_inverse=True)
            Y = measure(sd, self.cbs[k], users, self.sp, noisy=noisy)
            a, b_, c = link_inputs(Y, r[m, 1], pos, self.sp, self.aux_mode)
            sh[m], gl[m] = a, b_
            if ax.shape[1]:
                ax[m] = c
        return sh, gl, ax

    def __len__(self):
        return self.rows.shape[0]


# ----------------------------------------------------------------------------- evaluation
@torch.no_grad()
def gen_candidates(model, sd, cbs, sp, bl, ul, M, steps=8, aux_mode="full", noisy=True, use_meta=False, Y=None,
                   upos=None, chunk=1024):
    """Candidates W (n,M,N) and predicted log10 SNR for links (bl, ul)."""
    if Y is None:
        users, upos = torch.unique(ul, return_inverse=True)
        Y = measure(sd, cbs, users, sp, noisy=noisy)
    sh, gl, ax = link_inputs(Y, bl, upos, sp, aux_mode)
    Ws, gs = [], []
    for s in range(0, len(bl), chunk):
        sl = slice(s, s + chunk)
        meta = sd.bs_meta(0)[None].expand(sh[sl].shape[0], -1) if use_meta else None
        sid = torch.full((sh[sl].shape[0],), sd.site_id) if use_meta else None
        W, g = model.sample(sh[sl], gl[sl], ax[sl], M=M, steps=steps, meta=meta, site_idx=sid, return_gain=True)
        Ws.append(W)
        gs.append(g)
    return torch.cat(Ws), torch.cat(gs)


def gap_stats(h, W):
    g = cand_gain(h, W).amax(1)
    gap = 10 * torch.log10(g / mrt_gain(h))
    return gap


def beam_search(h, K, Q2, sp, noisy=True):
    """Two-tier hierarchical search: K coarse DFT beams, then Q2 oversampled beams within the cell."""
    N = h.shape[-1]
    C1 = dft_codebook(N, K)
    y1 = rsrp_db(h, C1, sp, noisy=noisy)
    k = y1.argmax(1)
    u_c = -1 + 2 * (k.float() + 0.5) / K
    off = (torch.arange(Q2).float() + 0.5) / Q2 * (2 / K) - 1 / K
    u = u_c[:, None] + off[None]
    n = torch.arange(N).float()
    W = (torch.exp(1j * math.pi * u[..., None] * n) / math.sqrt(N)).to(torch.complex64)  # (n,Q2,N)
    g = cand_gain(h, W)
    p = sp.pt * g + sp.noise
    if noisy:
        p = p + torch.sqrt((sp.noise ** 2 + 2 * sp.noise * sp.pt * g) / sp.ls) * torch.randn_like(p)
    j = p.argmax(1)
    return W[torch.arange(len(j)), j][:, None, :], W, y1


def srs_beam(h, sp, gen=None):
    """Idealised SRS-LMMSE: channel estimate with NMSE = 1/(1+Ls*SNR), phase-only MRT."""
    snr = sp.pt * (h.abs() ** 2).mean(-1) / sp.noise
    nmse = 1.0 / (1.0 + sp.ls * snr)
    e = (torch.randn(h.shape) + 1j * torch.randn(h.shape)) / math.sqrt(2)
    hh = h + torch.sqrt(nmse * (h.abs() ** 2).mean(-1))[:, None] * e.to(torch.complex64)
    w = torch.exp(1j * torch.angle(hh)) / math.sqrt(h.shape[-1])
    return w[:, None, :].to(torch.complex64), hh


# ----------------------------------------------------------------------------- scheduling
def wsr(sel_gain_true, w):
    pass


def schedule_drop(S_est, X_est, wts, noise_pt, mode="coord", iters=3):
    """One scheduling instance.
    S_est: (B,U,M) estimated serving gains (Pt*|h^H w|^2 / sigma^2 units, i.e. SNR).
    X_est: (B,U,M,B,U) estimated interference SNR caused at UE (i,v) by cell b choosing (u,m).
    wts:   (B,U) weights.  Returns choice (B,2) = (u,m) per cell.
    """
    Bn, U, M = S_est.shape
    # init: uncoordinated, each cell maximises weighted own rate assuming no interference
    flat = (wts[:, :, None] * torch.log2(1 + S_est)).reshape(Bn, -1)
    ch = flat.argmax(1)
    if mode == "unc":
        return torch.stack([ch // M, ch % M], 1)

    def total(choice):
        tot = 0.0
        for b in range(Bn):
            u, m = choice[b] // M, choice[b] % M
            I = sum(X_est[i, choice[i] // M, choice[i] % M, b, u] for i in range(Bn) if i != b)
            tot = tot + wts[b, u] * torch.log2(1 + S_est[b, u, m] / (1 + I))
        return tot

    for _ in range(iters):
        changed = False
        for b in range(Bn):
            # evaluate all options of cell b given others (vectorised)
            others = [i for i in range(Bn) if i != b]
            # own rate for each (u,m) with interference from others onto (b,u)
            I_own = sum(X_est[i, ch[i] // M, ch[i] % M, b, :] for i in others)  # (U,)
            own = wts[b][:, None] * torch.log2(1 + S_est[b] / (1 + I_own)[:, None])  # (U,M)
            # effect on others: each other cell i's scheduled user v_i
            eff = torch.zeros(U, M)
            for i in others:
                v, mi = ch[i] // M, ch[i] % M
                I_i = sum(X_est[j, ch[j] // M, ch[j] % M, i, v] for j in others if j != i)
                eff = eff + wts[i, v] * torch.log2(1 + S_est[i, v, mi] / (1 + I_i + X_est[b, :, :, i, v]))
            best = (own + eff).reshape(-1).argmax()
            if best != ch[b]:
                ch[b] = best
                changed = True
        if not changed:
            break
    return torch.stack([ch // M, ch % M], 1)


def schedule_exhaustive(S_est, X_est, wts):
    Bn, U, M = S_est.shape
    best, bc = -1, None
    import itertools
    for c in itertools.product(range(U * M), repeat=Bn):
        tot = 0.0
        for b in range(Bn):
            u, m = c[b] // M, c[b] % M
            I = sum(float(X_est[i, c[i] // M, c[i] % M, b, u]) for i in range(Bn) if i != b)
            tot += float(wts[b, u]) * math.log2(1 + float(S_est[b, u, m]) / (1 + I))
        if tot > best:
            best, bc = tot, c
    return torch.tensor([[x // M, x % M] for x in bc])


def true_sinr(choice, Wc, Hcell, sp):
    """choice (B,2); Wc[b]: (U,M,N) candidate beams of cell b; Hcell[b][i]: (U,N) channel from BS i to UEs of cell b."""
    Bn = len(Wc)
    out = []
    for b in range(Bn):
        u, m = choice[b]
        w = Wc[b][u, m]
        s = sp.pt * (Hcell[b][b][u].conj() @ w).abs() ** 2
        I = 0.0
        for i in range(Bn):
            if i == b:
                continue
            ui, mi = choice[i]
            I = I + sp.pt * (Hcell[b][i][u].conj() @ Wc[i][ui, mi]).abs() ** 2
        out.append(s / (I + sp.noise))
    return torch.stack(out)
