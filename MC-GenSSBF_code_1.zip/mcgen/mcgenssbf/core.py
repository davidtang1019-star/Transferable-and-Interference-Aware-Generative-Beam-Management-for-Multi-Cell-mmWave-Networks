"""Core blocks: RSRP measurement, interference-aware SIM codebook, multi-cell
conditional flow matching (CFM) with site embedding and LoRA, baselines.

Extends the single-cell Gen-SSBF reference implementation (Zhao, Wang, Liu,
IEEE TSP 2026) to multi-cell, multi-site operation.
"""
import math
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

LN10 = math.log(10.0)


# ----------------------------------------------------------------------------- system
class SysParams:
    def __init__(self, n_ant=32, K=8, M=8, pt_dbm=30.0, bw=100e6, n0_dbm_hz=-170.0, ls=5,
                 sh_db=1.0, q_serv_db=1.0, q_nb_bits=4, nb_range_db=30.0, floor_snr_db=-6.0):
        self.n_ant, self.K, self.M = n_ant, K, M
        self.pt_dbm, self.bw, self.n0_dbm_hz, self.ls = pt_dbm, bw, n0_dbm_hz, ls
        self.sh_db = sh_db
        self.q_serv_db = q_serv_db          # serving RSRP report granularity (dB)
        self.q_nb_bits = q_nb_bits          # neighbour differential RSRP bits
        self.nb_range_db = nb_range_db      # neighbour differential range (dB)
        self.floor_snr_db = floor_snr_db    # RSRP detection floor relative to noise

    @property
    def pt(self):
        return 10 ** (self.pt_dbm / 10) * 1e-3

    @property
    def noise(self):
        return 10 ** ((self.n0_dbm_hz + 10 * math.log10(self.bw)) / 10) * 1e-3

    def copy(self, **kw):
        p = SysParams()
        p.__dict__.update(self.__dict__)
        p.__dict__.update(kw)
        return p


def beam_gain(h, w):
    """h:(...,N) complex, w:(N,K) complex -> |h^H w|^2 (...,K)."""
    y = h.conj() @ w
    return y.real ** 2 + y.imag ** 2


def rsrp_db(h, w, sp: SysParams, noisy=True, quantize=None):
    """Measured RSRP in dBm for every probing beam. Differentiable in w when quantize=False."""
    g = beam_gain(h, w)
    p_sig = sp.pt * g
    n2 = sp.noise
    p = p_sig + n2
    if noisy:
        var_p = (n2 ** 2 + 2 * n2 * p_sig) / sp.ls
        p = p + torch.sqrt(var_p) * torch.randn_like(p)
    floor = n2 * 10 ** (sp.floor_snr_db / 10)
    p = torch.clamp(p, min=floor)
    y = 10 * torch.log10(p) + 30.0
    if noisy and sp.sh_db > 0:
        y = y + math.sqrt(sp.sh_db) * torch.randn(y.shape[:-1] + (1,), device=y.device)
    if quantize is None:
        quantize = noisy
    if quantize and sp.q_serv_db > 0:
        y = y + (torch.round(y / sp.q_serv_db) * sp.q_serv_db - y).detach()  # straight-through
    return y


def quantize_neighbour(y_nb, y_ref_max, sp: SysParams):
    """Differential quantisation of neighbour RSRP relative to the serving maximum."""
    if sp.q_nb_bits is None or sp.q_nb_bits <= 0:
        return y_nb
    lv = 2 ** sp.q_nb_bits
    step = sp.nb_range_db / (lv - 1)
    d = torch.clamp(y_ref_max[..., None] - y_nb, 0.0, sp.nb_range_db)
    d = d + (torch.round(d / step) * step - d).detach()  # straight-through
    return y_ref_max[..., None] - d


# ----------------------------------------------------------------------------- codebooks
def dft_codebook(N, K):
    """K DFT beams spread uniformly over the spatial-frequency range [-1,1)."""
    n = torch.arange(N, dtype=torch.float32)
    u = -1 + 2 * (torch.arange(K, dtype=torch.float32) + 0.5) / K
    return (torch.exp(1j * math.pi * n[:, None] * u[None, :]) / math.sqrt(N)).to(torch.complex64)


def steer(N, u):
    n = torch.arange(N, dtype=torch.float32)
    return (torch.exp(1j * math.pi * n[:, None] * u[None, :]) / math.sqrt(N)).to(torch.complex64)


class PhaseCodebook(nn.Module):
    def __init__(self, N, K, seed=0, init=None):
        super().__init__()
        g = torch.Generator().manual_seed(seed)
        if init is None:
            phi = 2 * math.pi * torch.rand(K, N, generator=g) - math.pi
        else:
            phi = torch.angle(init).T.contiguous().float()
        self.phi = nn.Parameter(phi)

    def forward(self):
        return (torch.exp(1j * self.phi) / math.sqrt(self.phi.shape[1])).T.contiguous()


def _shape_norm(y):
    return (y - y.mean(1, keepdim=True)) / (y.std(1, keepdim=True) + 1e-3)


def logdet_cov(x, eps=1e-3):
    xc = x - x.mean(0, keepdim=True)
    cov = xc.T @ xc / max(x.shape[0] - 1, 1) + eps * torch.eye(x.shape[1])
    return torch.linalg.slogdet(cov)[1]


def orth_penalty(w):
    wn = w / torch.linalg.norm(w, dim=0, keepdim=True)
    g = wn.conj().T @ wn
    return ((g - torch.eye(w.shape[1])).abs() ** 2).sum()


def train_codebook(h_serv, h_int, sp: SysParams, mode="ia", epochs=60, bs=512, lr=3e-2,
                   lam_orth=0.1, lam_cov=0.01, lam_int=0.5, beta=0.5, seed=0, init=None, verbose=False, w_int=None, y_int_serv=None):
    """Interference-aware SIM codebook (mode='ia') or single-user SIM (mode='su').

    h_serv: channels of UEs served by this BS; h_int: channels from this BS to
    neighbour-cell UEs that it interferes with (interference subspace samples).
    Objective (minimised): -logdet R_y(serv) - lam_int * logdet R_y(int)
                           + lam_orth * L_orth - lam_cov * mean softmax_k y_k / 10
    """
    torch.manual_seed(seed)
    cb = PhaseCodebook(sp.n_ant, sp.K, seed=seed, init=init)
    opt = torch.optim.Adam(cb.parameters(), lr=lr)
    hist = []
    ns = h_serv.shape[0]
    ni = h_int.shape[0] if h_int is not None else 0
    steps = max(ns // bs, 1)
    for ep in range(epochs):
        for _ in range(steps):
            w = cb()
            hs = h_serv[torch.randint(ns, (min(bs, ns),))]
            ys = rsrp_db(hs, w, sp, noisy=False, quantize=False)
            info = logdet_cov(_shape_norm(ys))
            ymax = beta * torch.logsumexp(ys / beta, 1) / 10.0
            loss = -info + lam_orth * orth_penalty(w) - lam_cov * ymax.mean()
            if mode == "ia" and ni > 8:
                if w_int is not None:
                    sel = torch.multinomial(w_int, min(bs, ni), replacement=True)
                else:
                    sel = torch.randint(ni, (min(bs, ni),))
                hi = h_int[sel]
                yi = rsrp_db(hi, w, sp, noisy=False, quantize=False)
                if y_int_serv is not None:
                    # conditional information of the interference link given the victim's serving report:
                    # logdet cov([y_b; y_s]) - logdet cov(y_s)  (second term constant in w)
                    info_i = logdet_cov(torch.cat([yi, y_int_serv[sel]], 1) / 10.0)
                else:
                    info_i = logdet_cov(_shape_norm(yi))
                loss = loss - lam_int * info_i - lam_cov * (beta * torch.logsumexp(yi / beta, 1) / 10.0).mean()
            opt.zero_grad()
            loss.backward()
            opt.step()
        hist.append(float(loss.detach()))
        if verbose and ep % 10 == 0:
            print("cb ep", ep, hist[-1])
    return cb().detach(), hist


# ----------------------------------------------------------------------------- targets
def mrt_target(h):
    """DFT-domain representation of the phase-only MRT beam (as in the reference code)."""
    N = h.shape[-1]
    w = torch.exp(1j * torch.angle(h)) / math.sqrt(N)
    y = torch.fft.fft(w, dim=-1)
    return torch.stack([y.real, y.imag], -2)


def y_to_beam(y):
    yc = y[..., 0, :] + 1j * y[..., 1, :]
    w = torch.fft.ifft(yc, dim=-1)
    return (torch.exp(1j * torch.angle(w)) / math.sqrt(w.shape[-1])).to(torch.complex64)


def mrt_gain(h):
    return h.abs().sum(-1) ** 2 / h.shape[-1]


def cand_gain(h, W):
    """h:(B,N), W:(B,M,N) -> (B,M) gains |h^H w|^2."""
    y = (h.conj()[:, None, :] * W).sum(-1)
    return y.real ** 2 + y.imag ** 2


# ----------------------------------------------------------------------------- features
def link_features(y_prim, y_aux, sp: SysParams, aux_mode="full"):
    """Condition features for one link.
    y_prim: (B,K) RSRP (dBm) of the UE on the probing codebook of the BS of the link.
    y_aux:  (B,A,K) RSRP of the UE on the other cells' codebooks (or None).
    """
    mu = y_prim.mean(1, keepdim=True)
    sd = y_prim.std(1, keepdim=True)
    shape = (y_prim - mu) / (sd + 1e-3)
    glob = torch.cat([(mu + 80.0) / 20.0, sd / 10.0], 1)
    if y_aux is None or aux_mode == "none":
        aux = torch.zeros(y_prim.shape[0], 0)
    elif aux_mode == "full":
        aux = ((y_aux - mu[:, :, None]) / 20.0).reshape(y_prim.shape[0], -1)
    elif aux_mode == "stats":
        aux = torch.cat([(y_aux.mean(-1) - mu) / 20.0, y_aux.std(-1) / 10.0, (y_aux.amax(-1) - mu) / 20.0], 1)
    else:
        raise ValueError(aux_mode)
    return shape, glob, aux


# ----------------------------------------------------------------------------- networks
class LoRALinear(nn.Module):
    def __init__(self, base: nn.Linear, r=4, alpha=8.0):
        super().__init__()
        self.base = base
        self.r = r
        self.A = nn.Parameter(torch.randn(r, base.in_features) * 0.01)
        self.B = nn.Parameter(torch.zeros(base.out_features, r))
        self.scale = alpha / r
        self.enabled = False

    def forward(self, x):
        out = self.base(x)
        if self.enabled:
            out = out + (x @ self.A.T @ self.B.T) * self.scale
        return out


class FiLMBlock(nn.Module):
    def __init__(self, i, o, c):
        super().__init__()
        self.lin = nn.Linear(i, o)
        self.norm = nn.LayerNorm(o)
        self.g = nn.Linear(c, o)
        self.b = nn.Linear(c, o)

    def forward(self, x, c):
        return F.silu(self.g(c) * self.norm(self.lin(x)) + self.b(c))


def _mlp(i, o):
    return nn.Sequential(nn.Linear(i, o), nn.LayerNorm(o), nn.SiLU(), nn.Linear(o, o), nn.LayerNorm(o), nn.SiLU())


class MCCondEncoder(nn.Module):
    """Shape branch, scale branch, interference (neighbour RSRP) branch, site branch -> FiLM fusion."""

    def __init__(self, K, aux_dim, meta_dim, c=128, n_sites=0):
        super().__init__()
        self.shape = _mlp(K, c)
        self.scale = nn.Sequential(nn.Linear(2, c), nn.SiLU(), nn.Linear(c, c), nn.SiLU())
        self.aux_dim = aux_dim
        if aux_dim > 0:
            self.aux = nn.Sequential(nn.Linear(aux_dim, c), nn.SiLU(), nn.Linear(c, c), nn.SiLU())
        self.meta_dim = meta_dim
        if meta_dim > 0:
            self.meta = nn.Sequential(nn.Linear(meta_dim, c), nn.SiLU(), nn.Linear(c, c))
            self.site_offset = nn.Parameter(torch.zeros(max(n_sites, 1), c))
        self.fg = nn.Linear(c, c)
        self.fb = nn.Linear(c, c)

    def forward(self, shape, glob, aux, meta=None, site_idx=None):
        e = self.scale(glob)
        if self.aux_dim > 0:
            e = e + self.aux(aux)
        if self.meta_dim > 0 and meta is not None:
            em = self.meta(meta)
            if site_idx is not None:
                em = em + self.site_offset[site_idx]
            e = e + em
        s = self.shape(shape)
        return self.fg(e) * s + self.fb(e)


class MCCFM(nn.Module):
    """Multi-cell conditional flow-matching beam generator (one shared network for all links)."""

    def __init__(self, N, K, aux_dim=0, meta_dim=0, n_sites=0, c=128, width=256, depth=3,
                 sigma0=1.0, temperature=0.5, lora_r=4):
        super().__init__()
        self.N, self.sigma0, self.temperature = N, sigma0, temperature
        self.enc = MCCondEncoder(K, aux_dim, meta_dim, c, n_sites)
        blocks, i = [], 2 * N + 1
        for _ in range(depth):
            blocks.append(FiLMBlock(i, width, c))
            i = width
        self.blocks = nn.ModuleList(blocks)
        self.out = nn.Linear(width, 2 * N)
        self.gain_head = nn.Sequential(nn.Linear(c, c), nn.SiLU(), nn.Linear(c, 1))
        # LoRA adapters (disabled until adaptation)
        for blk in self.blocks:
            blk.lin = LoRALinear(blk.lin, r=lora_r)
        self.out = LoRALinear(self.out, r=lora_r)

    def lora_modules(self):
        return [b.lin for b in self.blocks] + [self.out]

    def set_lora(self, on=True):
        for m in self.lora_modules():
            m.enabled = on

    def field(self, z, t, c):
        x = torch.cat([z.reshape(z.shape[0], -1), t[:, None]], 1)
        for blk in self.blocks:
            x = blk(x, c)
        return self.out(x).view(z.shape[0], 2, self.N)

    def cond(self, shape, glob, aux, meta=None, site_idx=None):
        return self.enc(shape, glob, aux, meta, site_idx)

    def loss(self, shape, glob, aux, target, log_gain=None, meta=None, site_idx=None, gain_w=0.1):
        c = self.cond(shape, glob, aux, meta, site_idx)
        t = torch.rand(target.shape[0])
        z0 = torch.randn_like(target) * self.sigma0
        zt = (1 - t)[:, None, None] * z0 + t[:, None, None] * target
        l = F.mse_loss(self.field(zt, t, c), target - z0)
        if log_gain is not None:
            l = l + gain_w * F.mse_loss(self.gain_head(c).squeeze(1), log_gain)
        return l

    @torch.no_grad()
    def sample(self, shape, glob, aux, M=8, steps=8, meta=None, site_idx=None, return_gain=False):
        Bn = shape.shape[0]
        c = self.cond(shape, glob, aux, meta, site_idx)
        cc = c[:, None, :].expand(Bn, M, c.shape[1]).reshape(Bn * M, -1)
        z = torch.randn(Bn * M, 2, self.N) * self.sigma0 * self.temperature
        dt = 1.0 / steps
        for s in range(steps):
            t = torch.full((Bn * M,), s * dt)
            z = z + dt * self.field(z, t, cc)
        W = y_to_beam(z.view(Bn, M, 2, self.N))
        if return_gain:
            return W, self.gain_head(c).squeeze(1)
        return W


class MLPBeam(nn.Module):
    """Discriminative baseline (DisSSBF): deterministic regression RSRP -> beam (DFT domain)."""

    def __init__(self, N, K, aux_dim=0, c=128, width=256):
        super().__init__()
        self.N = N
        self.enc = MCCondEncoder(K, aux_dim, 0, c)
        self.net = nn.Sequential(nn.Linear(c, width), nn.SiLU(), nn.Linear(width, width), nn.SiLU(),
                                 nn.Linear(width, 2 * N))
        self.gain_head = nn.Sequential(nn.Linear(c, c), nn.SiLU(), nn.Linear(c, 1))

    def loss(self, shape, glob, aux, target, log_gain=None, meta=None, site_idx=None, gain_w=0.1):
        c = self.enc(shape, glob, aux)
        l = F.mse_loss(self.net(c).view(-1, 2, self.N), target)
        if log_gain is not None:
            l = l + gain_w * F.mse_loss(self.gain_head(c).squeeze(1), log_gain)
        return l

    @torch.no_grad()
    def sample(self, shape, glob, aux, M=1, steps=None, meta=None, site_idx=None, return_gain=False):
        c = self.enc(shape, glob, aux)
        W = y_to_beam(self.net(c).view(-1, 1, 2, self.N))
        if return_gain:
            return W, self.gain_head(c).squeeze(1)
        return W


class DiffusionBeam(nn.Module):
    """DDPM/DDIM baseline (diffusion GenSSBF) using the same FiLM backbone, epsilon-prediction."""

    def __init__(self, N, K, aux_dim=0, c=128, width=256, depth=3, T=500, temperature=0.5):
        super().__init__()
        self.base = MCCFM(N, K, aux_dim, 0, 0, c, width, depth)
        self.T = T
        betas = torch.linspace(1e-4, 0.02, T)
        self.register_buffer("abar", torch.cumprod(1 - betas, 0))
        self.N = N
        self.temperature = temperature

    def loss(self, shape, glob, aux, target, log_gain=None, meta=None, site_idx=None, gain_w=0.1):
        c = self.base.cond(shape, glob, aux)
        t = torch.randint(0, self.T, (target.shape[0],))
        ab = self.abar[t][:, None, None]
        eps = torch.randn_like(target)
        x = ab.sqrt() * target + (1 - ab).sqrt() * eps
        l = F.mse_loss(self.base.field(x, t.float() / self.T, c), eps)
        if log_gain is not None:
            l = l + gain_w * F.mse_loss(self.base.gain_head(c).squeeze(1), log_gain)
        return l

    @torch.no_grad()
    def sample(self, shape, glob, aux, M=8, steps=50, meta=None, site_idx=None, return_gain=False):
        Bn = shape.shape[0]
        c = self.base.cond(shape, glob, aux)
        cc = c[:, None, :].expand(Bn, M, c.shape[1]).reshape(Bn * M, -1)
        x = torch.randn(Bn * M, 2, self.N) * self.temperature
        ts = torch.linspace(self.T - 1, 0, steps).long()
        for i, t in enumerate(ts):  # deterministic DDIM
            ab = self.abar[t]
            eps = self.base.field(x, torch.full((Bn * M,), float(t) / self.T), cc)
            x0 = (x - (1 - ab).sqrt() * eps) / ab.sqrt()
            ab_prev = self.abar[ts[i + 1]] if i + 1 < len(ts) else torch.tensor(1.0)
            x = ab_prev.sqrt() * x0 + (1 - ab_prev).sqrt() * eps
        W = y_to_beam(x.view(Bn, M, 2, self.N))
        if return_gain:
            return W, self.base.gain_head(c).squeeze(1)
        return W


# ----------------------------------------------------------------------------- training loop
def train_generator(model, feats, target, log_gain, epochs=40, bs=256, lr=1e-3, wd=1e-4, meta=None,
                    site_idx=None, params=None, verbose=False, resample=None, clip=1.0):
    """feats: tuple(shape, glob, aux). resample: optional callable(idx)->feats (fresh RSRP noise)."""
    opt = torch.optim.AdamW(params if params is not None else model.parameters(), lr=lr, weight_decay=wd)
    n = target.shape[0]
    steps_per = max(int(math.ceil(n / bs)), 1)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs * steps_per)
    hist = []
    model.train()
    for ep in range(epochs):
        perm = torch.randperm(n)
        tot = 0.0
        for s in range(steps_per):
            idx = perm[s * bs:(s + 1) * bs]
            if resample is not None:
                sh, gl, ax = resample(idx)
            else:
                sh, gl, ax = feats[0][idx], feats[1][idx], feats[2][idx]
            l = model.loss(sh, gl, ax, target[idx], log_gain[idx],
                           None if meta is None else meta[idx], None if site_idx is None else site_idx[idx])
            opt.zero_grad()
            l.backward()
            torch.nn.utils.clip_grad_norm_(params if params is not None else model.parameters(), clip)
            opt.step()
            sched.step()
            tot += float(l)
        hist.append(tot / steps_per)
        if verbose and (ep % 10 == 0 or ep == epochs - 1):
            print(f"  ep {ep} loss {hist[-1]:.4f}", flush=True)
    model.eval()
    return hist


def latency_ms(fn, warmup=1, repeat=3):
    for _ in range(warmup):
        fn()
    t = time.perf_counter()
    for _ in range(repeat):
        fn()
    return 1000 * (time.perf_counter() - t) / repeat
