"""Sensitivity of the interference-aware SIM codebook to (lam_int, lam_cov)."""
import sys
import time
from pathlib import Path

import numpy as np
import torch

from exp_insite import load_site
from mcgenssbf.core import SysParams
from mcgenssbf.schemes import codebook_set, codebook_metrics, make_gen, fit_gen, GenScheme, link_eval

torch.set_num_threads(2)


def main():
    site = sys.argv[1]
    seed = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    K = int(sys.argv[3]) if len(sys.argv) > 3 else 8
    sp = SysParams(n_ant=32, K=K, M=8)
    sd = load_site(site, sp.n_ant)
    out = {}
    t0 = time.time()
    for li in (0.0, 0.1, 0.25, 0.5, 1.0):
        for lc in (0.05,):
            torch.manual_seed(seed)
            cbs = codebook_set(sd, sp, "ia" if li > 0 else "su", seed=seed, epochs=60, lam_int=li, lam_cov=lc)
            cm = codebook_metrics(sd, cbs, sp)
            m = make_gen("cfm", sp, "full")
            fit_gen(m, [sd], [cbs], sp, "full", epochs=30, seed=seed)
            r = link_eval(GenScheme("x", cbs, m, "full"), sd, sp, 8)
            out[(li, lc)] = {**cm, "gap": float(r["gap"].mean()), "leak_mae": float(r["leak_err_db"].abs().mean()),
                             "leak_med": float(r["leak_err_db"].abs().median()),
                             "leak_mae_strong": float(r["leak_err_db"][r["leak_strong"]].abs().mean())}
            print(site, li, lc, {k: round(v, 3) for k, v in out[(li, lc)].items()}, f"{time.time()-t0:.0f}s",
                  flush=True)
    Path("results").mkdir(exist_ok=True)
    torch.save(out, f"results/sweep_ia_{site}_K{K}_s{seed}.pt")


if __name__ == "__main__":
    main()
