import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle
from mcgenssbf.sites import default_sites, make_site, build_site_dataset
plt.rcParams.update({"font.size": 9})
cols = ["#2a6f97", "#c8553d", "#6a994e"]
fig, axs = plt.subplots(1, 2, figsize=(9, 4.2))
for ax, name in zip(axs, ("LOS-1", "BLK-1")):
    cfg = [c for c in default_sites() if c.name == name][0]
    st = make_site(cfg, ue_spacing=0.6)
    d = build_site_dataset(st, 32)
    U = d["H"].shape[1]
    sv = d["serving"]
    g = (np.abs(d["H"]).sum(-1) ** 2 / 32)
    sig = g[sv, np.arange(U)]
    sir = 10 * np.log10(sig / (g.sum(0) - sig + 1e-30))
    for b in range(3):
        m = sv == b
        ax.scatter(d["xy"][m, 0], d["xy"][m, 1], s=0.15, c=cols[b], alpha=0.35, rasterized=True)
    edge = sir < 10
    ax.scatter(d["xy"][edge, 0], d["xy"][edge, 1], s=0.15, c="k", alpha=0.5, rasterized=True)
    for q in st.rects:
        ax.add_patch(Rectangle((q[0], q[1]), q[2] - q[0], q[3] - q[1], fc="#999999", ec="k", lw=0.5))
    ax.scatter(st.scat_xy[:, 0], st.scat_xy[:, 1], marker="x", c="k", s=14, lw=0.8)
    for b in range(3):
        x, y = st.bs_xy[b]
        ax.plot(x, y, "^", ms=9, c=cols[b], mec="k")
        ax.arrow(x, y, 9 * np.cos(st.bs_boresight[b]), 9 * np.sin(st.bs_boresight[b]), head_width=2, color="k", lw=0.6)
        ax.text(x + 2, y + 3, f"BS{b+1}", fontsize=8)
    los = d["los"][sv, np.arange(U)].mean()
    ax.set_title(f"{name}: {U} UE locations, LoS share {100*los:.0f}%", fontsize=9)
    ax.set_aspect("equal"); ax.set_xlabel("x (m)"); ax.set_ylabel("y (m)")
plt.tight_layout()
plt.savefig("/home/claude/paper/figs/fig_sites.pdf", bbox_inches="tight", dpi=200)
plt.savefig("/home/claude/paper/figs/fig_sites.png", bbox_inches="tight", dpi=130)
# site statistics table
rows = []
for c in default_sites():
    st = make_site(c, ue_spacing=0.6); d = build_site_dataset(st, 32)
    U = d["H"].shape[1]; sv = d["serving"]; g = (np.abs(d["H"]).sum(-1) ** 2 / 32)
    sig = g[sv, np.arange(U)]; sir = 10 * np.log10(sig / (g.sum(0) - sig + 1e-30))
    snr = 10 * np.log10(sig / 1e-12)
    rows.append((c.name, U, len(st.rects), c.n_scatterers, float(np.mean(st.bs_h)), c.isd, 100 * d["los"][sv, np.arange(U)].mean(), np.median(snr), 100 * np.mean(sir < 10)))
for r in rows:
    print("%s & %d & %d & %d & %.1f & %.0f & %.0f & %.1f & %.0f \\\\" % r)
