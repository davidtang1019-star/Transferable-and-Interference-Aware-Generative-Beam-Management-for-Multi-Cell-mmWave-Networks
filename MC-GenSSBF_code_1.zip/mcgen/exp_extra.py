"""Additional experiments.

python exp_extra.py latency SITE SEED      -> CFM vs diffusion: gap / latency vs steps, N_t in {16,32,64}
python exp_extra.py ksweep SITE SEED       -> K sweep (gap, WSR, overhead)
python exp_extra.py robust SITE SEED       -> robustness to shadowing, neighbour quantisation, blockage
"""
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch

from exp_insite import load_site
from mcgenssbf.core import SysParams, cand_gain, mrt_gain
from mcgenssbf.pipeline import B, measure, link_inputs
from mcgenssbf.schemes import (codebook_set, make_gen, fit_gen, GenScheme, link_eval, network_eval, summarize)

torch.set_num_threads(int(__import__("os").environ.get("NTHREADS", "2")))
OUT = Path("results")


def diversity(W):
    """Mean pairwise (1 - |w_i^H w_j|^2) among the M candidates."""
    G = (W.conj() @ W.transpose(-1, -2)).abs() ** 2
    M = W.shape[1]
    off = (G.sum((-1, -2)) - G.diagonal(dim1=-2, dim2=-1).sum(-1)) / (M * (M - 1))
    return float((1 - off).mean())


def latency(site, seed):
    R = {}
    for N in (16, 32, 64):
        sp = SysParams(n_ant=N, K=8, M=8)
        sd = load_site(site, N)
        cbs = codebook_set(sd, sp, "cia", seed=seed, lam_int=0.1)
        torch.manual_seed(seed)
        cfm = make_gen("cfm", sp, "full")
        fit_gen(cfm, [sd], [cbs], sp, "full", epochs=40, seed=seed)
        torch.manual_seed(seed)
        dif = make_gen("diff", sp, "full")
        fit_gen(dif, [sd], [cbs], sp, "full", epochs=40, seed=seed)
        users = sd.idx["test"][:128]
        s = sd.serv[users]
        torch.manual_seed(seed)
        Y = measure(sd, cbs, users, sp)
        sh, gl, ax = link_inputs(Y, s, torch.arange(len(users)), sp, "full")
        h = sd.H[s, users]
        row = {"cfm": {}, "diff": {}}
        for name, model, steps_list in (("cfm", cfm, (1, 2, 4, 8, 16, 40)), ("diff", dif, (5, 10, 20, 50, 100, 250))):
            for st in steps_list:
                gaps, divs = [], []
                ev = link_eval(GenScheme("x", cbs, model, "full", steps=st), sd, sp, 8)
                W = model.sample(sh, gl, ax, M=8, steps=st)
                t = []
                for _ in range(3):
                    t0 = time.perf_counter()
                    model.sample(sh, gl, ax, M=8, steps=st)
                    t.append(time.perf_counter() - t0)
                row[name][st] = {"gap": float(ev["gap"].mean()), "lat_ms": 1000 * float(np.median(t)),
                                 "div": diversity(W)}
                print(N, name, st, row[name][st], flush=True)
        R[N] = row
    torch.save(R, OUT / f"latency_{site}_s{seed}.pt")


def ksweep(site, seed):
    R = {}
    for K in (4, 8, 16):
        sp = SysParams(n_ant=32, K=K, M=8)
        sd = load_site(site, 32)
        row = {}
        for cbk, aux in (("dft", "none"), ("su", "none"), ("cia", "full")):
            cbs = codebook_set(sd, sp, cbk, seed=seed, lam_int=0.1)
            torch.manual_seed(seed)
            m = make_gen("cfm", sp, aux)
            fit_gen(m, [sd], [cbs], sp, aux, epochs=40, seed=seed)
            sc = GenScheme(cbk, cbs, m, aux)
            ev = link_eval(sc, sd, sp, 8)
            net = network_eval(sd, sp, [sc], n_drops=150, U=4, M=8, seed=seed, sched_modes=("coord",))
            row[cbk] = {"gap": float(ev["gap"].mean()), "leak_mae_strong": float(ev["leak_err_db"][ev["leak_strong"]].abs().mean()),
                        **summarize(net[cbk]["coord"])}
            print(K, cbk, {k: round(v, 3) for k, v in row[cbk].items()}, flush=True)
        R[K] = row
    torch.save(R, OUT / f"ksweep_{site}_s{seed}.pt")


def robust(site, seed):
    sp = SysParams(n_ant=32, K=8, M=8)
    sd = load_site(site, 32)
    R = {}
    models = {}
    for name, cbk, aux in (("SU-SIM+CFM", "su", "none"), ("CIA-SIM+MC-CFM", "cia", "full")):
        cbs = codebook_set(sd, sp, cbk, seed=seed, lam_int=0.1)
        torch.manual_seed(seed)
        m = make_gen("cfm", sp, aux)
        fit_gen(m, [sd], [cbs], sp, aux, epochs=40, seed=seed)
        models[name] = GenScheme(name, cbs, m, aux)
    conds = {"nominal": sp, "shadow 2 dB^2": sp.copy(sh_db=2.0), "shadow 4 dB^2": sp.copy(sh_db=4.0),
             "nb 2-bit": sp.copy(q_nb_bits=2), "nb 6-bit": sp.copy(q_nb_bits=6),
             "serv 2 dB step": sp.copy(q_serv_db=2.0)}
    for cn, spc in conds.items():
        R[cn] = {}
        for name, sc in models.items():
            ev = link_eval(sc, sd, spc, 8)
            net = network_eval(sd, spc, [sc], n_drops=150, U=4, M=8, seed=seed, sched_modes=("coord",))
            R[cn][name] = {"gap": float(ev["gap"].mean()), **summarize(net[name]["coord"])}
            print(cn, name, {k: round(v, 3) for k, v in R[cn][name].items()}, flush=True)
    # unseen blockage: remove the LoS component for 30% of test UEs (new obstacle), channels recomputed
    from mcgenssbf.sites import default_sites, make_site, site_paths, ula_channels
    cfg = [c for c in default_sites() if c.name == site][0]
    st = make_site(cfg, ue_spacing=0.6)
    H2 = sd.H.clone()
    te = sd.idx["test"]
    g = torch.Generator().manual_seed(seed)
    blk = te[torch.rand(len(te), generator=g) < 0.3]
    xy = sd.xy[blk.numpy()]
    for b in range(B):
        amps, aods = site_paths(st, b, ue_xy=xy)
        amps[:, 0] = 0.0
        H2[b, blk] = torch.from_numpy(ula_channels(amps, aods, 32).astype(np.complex64))
    from mcgenssbf.core import mrt_gain as mg
    # keep only UEs that still have a non-negligible serving link (otherwise revert: no coverage at all)
    dead = mg(H2[sd.serv[blk], blk]) < 1e-14
    H2[:, blk[dead]] = sd.H[:, blk[dead]]
    R_blk_frac = float((~dead).float().mean())
    sd.H = H2
    sd.G = mg(H2)
    R["blockage 30%"] = {}
    for name, sc in models.items():
        ev = link_eval(sc, sd, sp, 8)
        net = network_eval(sd, sp, [sc], n_drops=150, U=4, M=8, seed=seed, sched_modes=("coord",))
        R["blockage 30%"][name] = {"gap": float(ev["gap"].mean()), **summarize(net[name]["coord"])}
        print("blockage", name, {k: round(v, 3) for k, v in R["blockage 30%"][name].items()}, flush=True)
    torch.save(R, OUT / f"robust_{site}_s{seed}.pt")


if __name__ == "__main__":
    {"latency": latency, "ksweep": ksweep, "robust": robust}[sys.argv[1]](sys.argv[2], int(sys.argv[3]))
