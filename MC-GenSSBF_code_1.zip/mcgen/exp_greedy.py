"""Best-response vs exhaustive scheduling on realistic instances (true gains, hierarchical-search candidates)."""
import math, sys, torch, numpy as np
from exp_insite import load_site
from mcgenssbf.core import SysParams, cand_gain
from mcgenssbf.pipeline import beam_search, schedule_drop, schedule_exhaustive, B
torch.set_num_threads(1)
out = {}
for site in ("LOS-1", "BLK-1", "LOS-3", "BLK-3"):
    sp = SysParams(n_ant=32, K=8, M=4)
    sd = load_site(site, 32)
    te = sd.idx["test"]
    g = torch.Generator().manual_seed(0)
    pools = [te[sd.serv[te] == b] for b in range(B)]
    ratios, rounds = [], []
    for d in range(60):
        U = 4
        users = torch.stack([p[torch.randperm(len(p), generator=g)[:U]] for p in pools])
        W = [beam_search(sd.H[b, users[b]], sp.K, 4, sp, noisy=False)[1] for b in range(B)]
        S = torch.stack([sp.pt * cand_gain(sd.H[b, users[b]], W[b]) / sp.noise for b in range(B)])
        X = torch.zeros(B, U, 4, B, U)
        for b in range(B):
            for i in range(B):
                if i != b:
                    Wb = W[b].reshape(-1, sp.n_ant)
                    X[b, :, :, i, :] = (sp.pt * ((sd.H[b, users[i]].conj() @ Wb.T).abs() ** 2).T / sp.noise).view(U, 4, U)
        wts = 1 / torch.log2(1 + sp.pt * sd.G[sd.serv[users], users] / sp.noise)
        wts = wts / wts.mean()
        def val(c):
            tot = 0
            for b in range(B):
                u, m = c[b]
                I = sum(float(X[i, c[i][0], c[i][1], b, u]) for i in range(B) if i != b)
                tot += float(wts[b, u]) * math.log2(1 + float(S[b, u, m]) / (1 + I))
            return tot
        cg = schedule_drop(S, X, wts, 1.0, "coord").tolist()
        cu = schedule_drop(S, X, wts, 1.0, "unc").tolist()
        ce = schedule_exhaustive(S, X, wts).tolist()
        ratios.append((val(cg) / val(ce), val(cu) / val(ce)))
    r = np.array(ratios)
    out[site] = r
    print(site, "greedy/opt mean %.4f min %.4f  unc/opt mean %.4f min %.4f" % (r[:, 0].mean(), r[:, 0].min(), r[:, 1].mean(), r[:, 1].min()), flush=True)
torch.save(out, "results/greedy_real.pt")
