"""In-site experiments (site-specific training) on one site for one seed.

Usage: python exp_insite.py SITE SEED [--quick]
Writes results/insite_{SITE}_s{SEED}.pt
"""
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch

from mcgenssbf.sites import default_sites, make_site, build_site_dataset
from mcgenssbf.core import SysParams, PhaseCodebook, rsrp_db, logdet_cov, _shape_norm, orth_penalty, latency_ms
from mcgenssbf.pipeline import SiteData, B, LinkSet
from mcgenssbf.schemes import (codebook_set, codebook_metrics, GenScheme, make_gen, fit_gen, link_eval,
                               network_eval, summarize)

torch.set_num_threads(int(__import__("os").environ.get("NTHREADS", "2")))
OUT = Path("results")
OUT.mkdir(exist_ok=True)


def load_site(name, n_ant, spacing=0.6):
    cfg = [c for c in default_sites() if c.name == name][0]
    site = make_site(cfg, ue_spacing=spacing)
    return SiteData(build_site_dataset(site, n_ant))


def joint_refine(sd, cbs, model, sp, aux_mode, rounds=3, cb_steps=60, gen_epochs=8, lam_info=0.05, seed=0):
    """Alternating codebook/generator refinement: fix theta -> update phases by the CFM loss
    (+ IA-SIM regulariser); fix codebook -> update theta."""
    cbm = [PhaseCodebook(sp.n_ant, sp.K, init=c) for c in cbs]
    for r in range(rounds):
        params = [p for m in cbm for p in m.parameters()]
        opt = torch.optim.Adam(params, lr=5e-3)
        ls = LinkSet([sd], [[m() for m in cbm]], sp, "train", aux_mode, seed=seed)
        for p in model.parameters():
            p.requires_grad_(False)
        for it in range(cb_steps):
            idx = torch.randint(len(ls), (256,))
            ls.cbs = [[m() for m in cbm]]
            sh, gl, ax = ls.resample(idx)  # differentiable w.r.t. codebook phases (straight-through rounding below)
            l = model.loss(sh, gl, ax, ls.target[idx], ls.log_gain[idx])
            reg = 0.0
            for b, m in enumerate(cbm):
                w = m()
                hs = sd.h_serv(b)[torch.randint(sd.h_serv(b).shape[0], (256,))]
                reg = reg - lam_info * logdet_cov(_shape_norm(rsrp_db(hs, w, sp, noisy=False, quantize=False))) \
                      + 0.1 * lam_info * orth_penalty(w)
            opt.zero_grad()
            (l + reg).backward()
            opt.step()
        for p in model.parameters():
            p.requires_grad_(True)
        cbs = [m().detach() for m in cbm]
        fit_gen(model, [sd], [cbs], sp, aux_mode, epochs=gen_epochs, lr=3e-4, seed=seed + r)
    return cbs


def main():
    site, seed = sys.argv[1], int(sys.argv[2])
    quick = "--quick" in sys.argv
    torch.manual_seed(seed)
    np.random.seed(seed)
    sp = SysParams(n_ant=32, K=8, M=8, pt_dbm=30.0)
    ep = 6 if quick else 40
    cbe = 10 if quick else 60
    t0 = time.time()
    sd = load_site(site, sp.n_ant)
    print(site, "UEs", sd.H.shape[1], flush=True)
    R = {"site": site, "seed": seed, "n_ue": int(sd.H.shape[1])}

    cb = {k: codebook_set(sd, sp, k, seed=seed, epochs=cbe, lam_int=0.25 if k == "ia" else 0.1) for k in ("su", "ia", "cia")}
    cb["dft"] = codebook_set(sd, sp, "dft")
    R["codebook"] = {k: codebook_metrics(sd, v, sp) for k, v in cb.items()}
    R["codebooks"] = {k: [c.numpy() for c in v] for k, v in cb.items()}
    print("codebooks", json.dumps(R["codebook"]), f"{time.time()-t0:.0f}s", flush=True)

    specs = [  # name, codebook, generator, aux
        ("DFT+MLP", "dft", "mlp", "none"),
        ("DFT+CFM", "dft", "cfm", "none"),
        ("SU-SIM+CFM", "su", "cfm", "none"),
        ("SU-SIM+MC-CFM", "su", "cfm", "full"),
        ("IA-SIM+MC-CFM", "ia", "cfm", "full"),
        ("CIA-SIM+CFM", "cia", "cfm", "none"),
        ("CIA-SIM+MC-CFM", "cia", "cfm", "full"),
        ("CIA-SIM+MC-CFM (stats)", "cia", "cfm", "stats"),
    ]
    schemes = {}
    R["train_hist"] = {}
    for name, ck, gk, aux in specs:
        torch.manual_seed(seed)
        m = make_gen(gk, sp, aux)
        h, _ = fit_gen(m, [sd], [cb[ck]], sp, aux, epochs=ep, seed=seed, verbose=False)
        R["train_hist"][name] = h
        schemes[name] = GenScheme(name, cb[ck], m, aux, steps=8)
        print(f"trained {name} loss {h[-1]:.4f} {time.time()-t0:.0f}s", flush=True)

    # joint (alternating) codebook-generator optimisation, warm-started from the two-stage solution
    import copy
    mj = copy.deepcopy(schemes["CIA-SIM+MC-CFM"].model)
    cbj = joint_refine(sd, cb["cia"], mj, sp, "full", rounds=1 if quick else 3, cb_steps=10 if quick else 60,
                       gen_epochs=2 if quick else 8, seed=seed)
    schemes["Proposed"] = GenScheme("Proposed", cbj, mj, "full", steps=8)
    R["codebook"]["joint"] = codebook_metrics(sd, cbj, sp)
    print(f"joint done {time.time()-t0:.0f}s", flush=True)

    # ---- link-level: gap to MRT and leakage-estimation error
    R["link"] = {}
    for name, sc in schemes.items():
        r = link_eval(sc, sd, sp, sp.M if "MLP" not in name else 1)
        R["link"][name] = {"gap": r["gap"].numpy(), "leak_err_db": r["leak_err_db"].numpy(),
                           "leak_strong": r["leak_strong"].numpy()}
        print(f"link {name}: gap {r['gap'].mean():.2f} dB, leak |err| {r['leak_err_db'].abs().median():.2f} dB",
              flush=True)
    # gap vs M for the proposed scheme and SU-SIM baseline
    R["gap_vs_M"] = {}
    for name in ("SU-SIM+CFM", "CIA-SIM+MC-CFM", "Proposed", "DFT+CFM"):
        R["gap_vs_M"][name] = {M: float(link_eval(schemes[name], sd, sp, M)["gap"].mean()) for M in (1, 2, 4, 8, 16)}
    # gap vs Pt
    R["gap_vs_pt"] = {}
    for pt in (10.0, 20.0, 30.0, 40.0):
        spp = sp.copy(pt_dbm=pt)
        row = {}
        for name in ("DFT+MLP", "DFT+CFM", "SU-SIM+CFM", "CIA-SIM+MC-CFM", "Proposed"):
            row[name] = float(link_eval(schemes[name], sd, spp, sp.M if "MLP" not in name else 1)["gap"].mean())
        from mcgenssbf.pipeline import beam_search, srs_beam
        from mcgenssbf.core import cand_gain, mrt_gain
        te = sd.idx["test"][:1500]
        s = sd.serv[te]
        h = sd.H[s, te]
        wbs, _, _ = beam_search(h, sp.K, sp.M, spp)
        row["Beam search"] = float((10 * torch.log10(cand_gain(h, wbs).amax(1) / mrt_gain(h))).mean())
        wsrs, _ = srs_beam(h, spp)
        row["SRS-LMMSE"] = float((10 * torch.log10(cand_gain(h, wsrs).amax(1) / mrt_gain(h))).mean())
        R["gap_vs_pt"][pt] = row
    print("gap_vs_pt", R["gap_vs_pt"], flush=True)

    # ---- network level
    net_schemes = [schemes[n] for n in ("DFT+MLP", "DFT+CFM", "SU-SIM+CFM", "SU-SIM+MC-CFM", "IA-SIM+MC-CFM",
                                         "CIA-SIM+CFM", "CIA-SIM+MC-CFM", "CIA-SIM+MC-CFM (stats)", "Proposed")] + \
                  ["beamsearch", "srs", "genie"]
    nd = 40 if quick else 200
    R["net"] = {}
    for pt in (20.0, 30.0, 40.0):
        spp = sp.copy(pt_dbm=pt)
        res = network_eval(sd, spp, net_schemes, n_drops=nd, U=4, M=sp.M, seed=seed)
        # interference-aware candidate selection with genie cross-gains (scheduler upper bound) for proposed
        res2 = network_eval(sd, spp, [schemes["Proposed"]], n_drops=nd, U=4, M=sp.M, seed=seed,
                            sched_modes=("genie",))
        res["Proposed"]["genie"] = res2["Proposed"]["genie"]
        # best-index-only feedback ablation
        res3 = network_eval(sd, spp, [schemes["Proposed"]], n_drops=nd, U=4, M=sp.M, seed=seed,
                            sched_modes=("coord",), cqi_all=False)
        res["Proposed"]["coord_bestidx"] = res3["Proposed"]["coord"]
        R["net"][pt] = {k: {m: summarize(v) for m, v in d.items()} for k, d in res.items()}
        if pt == 30.0:
            R["net_raw30"] = res
        print(f"net pt={pt}:", {k: round(d.get('coord', d.get('unc'))['wsr'], 3) for k, d in R['net'][pt].items()},
              f"{time.time()-t0:.0f}s", flush=True)

    # ---- network level vs M (proposed, coordinated)
    R["net_vs_M"] = {}
    for M in (1, 2, 4, 8, 16):
        res = network_eval(sd, sp, [schemes["Proposed"], schemes["SU-SIM+CFM"]], n_drops=nd // 2, U=4, M=M,
                           seed=seed, sched_modes=("coord",))
        R["net_vs_M"][M] = {k: summarize(v["coord"]) for k, v in res.items()}
    print("net_vs_M", {M: round(v["Proposed"]["wsr"], 3) for M, v in R["net_vs_M"].items()}, flush=True)

    # ---- greedy vs exhaustive scheduler optimality (small instance)
    from mcgenssbf.pipeline import schedule_drop, schedule_exhaustive
    g = torch.Generator().manual_seed(seed)
    ratios = []
    for _ in range(10 if quick else 40):
        S = 10 ** (3 * torch.rand(3, 4, 4, generator=g))
        X = 10 ** (4 * torch.rand(3, 4, 4, 3, 4, generator=g) - 2)
        w = torch.rand(3, 4, generator=g) + 0.5

        def val(c):
            tot = 0
            for b in range(3):
                u, m = c[b]
                I = sum(float(X[i, c[i][0], c[i][1], b, u]) for i in range(3) if i != b)
                tot += float(w[b, u]) * math.log2(1 + float(S[b, u, m]) / (1 + I))
            return tot
        ratios.append(val(schedule_drop(S, X, w, 1.0, "coord").tolist()) / val(schedule_exhaustive(S, X, w).tolist()))
    R["greedy_ratio"] = ratios
    R["time_s"] = time.time() - t0
    torch.save(R, OUT / f"insite_{site}_s{seed}{'_quick' if quick else ''}.pt")
    print("done", f"{time.time()-t0:.0f}s", "greedy/opt", np.mean(ratios))


if __name__ == "__main__":
    main()
