# MC-GenSSBF: simulation code for "Transferable and Interference-Aware Generative Beam Management for Multi-Cell mmWave Networks"

Extends the single-cell Gen-SSBF reference code (Zhao, Wang, Liu, IEEE TSP 2026) to three-cell networks.

## Layout
- `mcgenssbf/sites.py` – site-specific 2.5-D ray model (LoS + first-order wall reflections + point scatterers, blockage), 10 sites (LOS-1..5, BLK-1..5)
- `mcgenssbf/core.py` – RSRP model with quantisation (straight-through), SIM / IA-SIM / CIA-SIM codebooks, MC-CFM generator (FiLM, site branch, LoRA), MLP and diffusion baselines
- `mcgenssbf/pipeline.py` – link sets, multi-cell measurement, hierarchical search, SRS-LMMSE, best-response and exhaustive scheduling
- `mcgenssbf/schemes.py` – scheme wrappers, link- and network-level evaluation
- `mcgenssbf/deepmimo_adapter.py` – adapter to feed DeepMIMO channels (untested here)
- `exp_insite.py SITE SEED` – main in-site experiment (Tables 5–8, Figs. 6–10)
- `exp_transfer.py SEED` – cross-site transfer (Fig. 11, Table 11)
- `exp_extra.py {ksweep|robust|latency} SITE SEED` – Tables 9–10, Fig. 12
- `exp_sweep_ia.py`, `exp_variants.py`, `exp_greedy.py` – IA sensitivity (Fig. 3), codebook variants, scheduler optimality
- `aggregate.py` – produces all result figures/tables (mean ± 95% t-CI) and `results/summary.json`
- `results/` – raw results (.pt) of every run reported in the paper

## Environment used
Python 3.13, PyTorch 2.14 (CPU), NumPy 2.5, SciPy 1.18, Matplotlib 3.11; 2-core CPU, no GPU.
Seeds 0–2; data split seed 7. Run `NTHREADS=1 python exp_insite.py LOS-1 0` etc., then `python aggregate.py`.
